//
//  ScistLocalSearch.hpp
//  
//
//  Created by Yufeng Wu on 12/16/22.
//  For fast local search of MLE
//  For the moment, only support haploid version

#ifndef ScistLocalSearch_hpp
#define ScistLocalSearch_hpp

#include <vector>
#include <map>
#include <set>
#include <string>
#include "Utils4.h"
#include "MarginalTree.h"
#include "ScistPerfPhyUtils.hpp"
class ScistPerfPhyGuideTree;
class ScistGenGenotypeMat;

// **************************************************************
// Fast rSPR local search

class ScistFastSPRLocalSearch
{
public:
    ScistFastSPRLocalSearch(const ScistGenGenotypeMat &genosInputIn, //const ScistPerfPhyGuideTree &treeGuideIn,
                            const string &strTreeInit, int nt);
    void SetNumThreads(int t) { numThreads = t; }
    void SetHeuristicMode(bool f, double frac, int t) { fHeu = f; fracHeuSPRSrc = frac; thresSPRDropStop = t; }
    void SetInitTree(const MarginalTree &mtreeInit);
    double CalcCurrMaxProb() const;
    void GetCurrTree(MarginalTree &treeOut) const;
    double GetOpt1SPRMove(int &nodeSPRSrc, int &nodeSPRDest, int &nodeLCA, std::vector<double> *pMapMaxProbSrc = NULL, std::vector<double> *pMapMaxProbDest = NULL, std::vector<std::vector<std::pair<int,double> > > *pMapSPRVal = NULL );
    double GetOpt1SPRMoveMT(int &nodeSPRSrc, int &nodeSPRDest, int &nodeLCA, std::vector<double> *pMapMaxProbSrc = NULL, std::vector<double> *pMapMaxProbDest = NULL, std::vector<std::vector<std::pair<int,double> > > *pMapSPRVal = NULL);
    double GetOptSubtreeReroot( int &nodeSTRootNew, int &nodeST );
    int GetNumSites() const;
    int GetNumCells() const;
    double GetCurrMaxProb() const { return this->logProbCurr; }
    void SetCurrMaxProb(double p) { this->logProbCurr = p; }
    double GetSumLogAllele0Prob() const { return this->sumLogprobAllele0; }
    void SetEdgeCandidate(int e, bool f) { listEdgeCandidacy[e] = f; }
    void SetEdgeCandidateDest(int e, bool f) { listEdgeCandidacyDest[e] = f; }
    void GetEdgeSrcCandidates( std::vector<bool> &listCand ) const { listCand = listEdgeCandidacy; }
    void SetEdgeSrcCandidates( const std::vector<bool> &listCand ) { listEdgeCandidacy = listCand; }
    
    // not really interface functions but for multithreading code...
    //double CalcMaxQForSPR(int site, int noder, int nodeu, int nodew, int nodewAnces, int nodeuAnces) const;
    double CalcMaxQForSPR(int site, int noder, int nodeu, int nodew, int nodev, int nodev1, int nodewAnces, int nodevAnces, int nodev1Ances, int nodevp, int nodevpAnces, int nodeuAnces) const;
    double CalcMaxQForReroot(int site, int node, int nodeSub, vector<vector<map<int,double> > > & tblM4) const;
    double GetQVal(int site, int node) const { return this->tblQ[site][node]; }
    double GetM0Val(int site, int node) const { return this->tblM0[site][node]; }
    bool IsNodeAncestralTo(int node1, int node2) const;
    int GetNumNodesInTree() const;
    int GetAncesIndex(int nodeDesc, int nodeAnces) const;
    double CalcMaxQPruneSite(int site, int noder, int nodeu) const;
    bool FastEvalSTForSPR(const std::set<int> &setTaxaST, double probMaxCurr ) const;
    void ForbidSTPrune(const std::set<int> &clade) { listForbidSTSrc.insert(clade); }
    void ForbidSTRegraft(const std::set<int> &clade) { listForbidSTDest.insert(clade); }
    void ForbidSTsPrune(const std::set<std::set<int> > &clades ) { UnionSetsGen(listForbidSTSrc, clades); }
    void ForbidSTsRegraft(const std::set<std::set<int> > &clades) { UnionSetsGen(listForbidSTDest, clades); }
    void ReInitForbid() { listForbidSTSrc.clear(); listForbidSTDest.clear(); }
    const std::set<std::set<int> > &GetForbidSTsPrune() const { return listForbidSTSrc; }
    const std::set<std::set<int> > &GetForbidSTsRegraft() const { return listForbidSTDest; }
    
private:
    void Init();
    void InitQTbl();
    void InitM0Tbl();
    void InitM0TblMT();
    void InitM1Tbl();
    void InitM1TblMT();
    void InitM2Tbl();
    void InitM2TblMT();
    void InitM10Tbl();
    void InitM8Tbl();
    void InitM9Tbl();
    void InitCandidates();
    std::string ConsTreeFromSetClusters( const std::set<ScistPerfPhyCluster> &setClusters ) const;
    // format: (LCA, (source of SPR, dest of SPR))
    void CollectAllSPRs(std::vector< std::set<std::pair<int,int> > > &listSPRs);
    void CollectAllSPRs2(std::vector< std::set<std::pair<int,int> > > &listSPRs);
    void CollectAllSPRs3(std::vector< std::set<std::pair<int,int> > > &listSPRs);
    void OrderSPRs(const std::vector< set<std::pair<int,int> > > &listSPRs, std::vector<std::pair<int, std::pair<int,int> > > &listSPRsOrdered) const;
    void ReduceCandidateSrcs();
    int GetNumAllowedSPRSrcs() const;
    int GetNumAncesForNode(int node) const { return mapListAnces[node].size(); }
    bool QuickCheckSPRSrc(int noder, int nodeu, int noderChildOtherSide, double maxQRootCur ) const;
    bool QuickCheckSPRHeu(int noder, int nodeChild, int noderChildOtherSide, double maxQRootCur) const;
    double CalcMaxQPrune(int noder, int nodeu, int noderChildOtherSide) const;
    double CalcMaxQPruneHeu(int noder, int nodeChild, int noderChildOtherSide) const;
    double CalcMaxQCurr() const;
    bool IsCladePrunable(const std::set<int> &clade) const { return listForbidSTSrc.find(clade) == listForbidSTSrc.end(); }
    bool IsCladeRegraftable(const std::set<int> &clade) const { return listForbidSTDest.find(clade) == listForbidSTDest.end(); }
    
    const ScistGenGenotypeMat &genosInput;
    //const ScistPerfPhyGuideTree &treeGuide;
    const string &strTreeInit;
    MarginalTree mtree;
    int numThreads;
    bool fHeu;
    double fracHeuSPRSrc;
    int thresSPRDropStop;
    double logProbCurr;
    double sumLogprobAllele0;
    std::vector<std::vector<double> > tblQ;
    std::vector<std::vector<double> > tblM0;
    std::vector<std::vector<double> > tblM0a;
    std::vector<std::vector< std::vector<double> > > tblM1;
    std::vector<std::vector< std::vector<double> > > tblM2;
#if 0
    std::vector<std::vector< std::vector<double> > > tblM10;    // for quick likelihood calc
    //std::vector<std::vector< std::map<int,double> > > tblM1;
    //std::vector<std::vector< std::map<int,double> > > tblM2;
    std::vector<std::vector<double> > tblM8;
    std::vector<std::vector<double> > tblM9;
    std::vector<std::vector<double> > tblM11;
#endif
    std::vector<bool> listEdgeCandidacy;    // [e] = true if edge e can be the source of rSPR
    std::vector<bool> listEdgeCandidacyDest;    // [e] = true if edge e can be the destination of rSPR
    std::set<std::set<int> > listForbidSTSrc;   // set of clades that are not to be pruned
    std::set<std::set<int> > listForbidSTDest;   // set of clades that are not to be regrafted into
    // helper: decide whether a node is ancestral to a node
    std::vector< set<int> > mapListAnces;
    std::vector< map<int,int> > mapListAncesLookup;     // which index of the ancestor for the particular ancestor to look up
};



// **************************************************************
// Fast rSPR local search to find opt tree
class ScistPerfPhyProbOnTree;

class ScistFastSPRLocalSearchLoop
{
public:
    ScistFastSPRLocalSearchLoop(const ScistGenGenotypeMat &genosInputIn, const string &strTreeInit /*const ScistPerfPhyGuideTree &treeGuideIn*/);
    double FindOpt(std::string &strTreeOpt);
    double FindOptMulti(string &strTreeOpt);
    void SetNumThreads(int t) {numThreads = t;}
    //void SetMaxHeuSPRsNum(int t) { maxMultiSPRsMoves = t; }
    void SetHeuristicMode(bool f, double frac, int t) { fHeu = f; heuFracSPR = frac; thresSPRDrop = t;}
    void SetVerbose(bool f) { fVerbose = f; }
    
private:
    void FindSPRSrcLoserFrom( const std::map<int, double> &mapSrcScore, const std::set<int> &setAvoided, double frac, std::set<int> &setSrcLosers ) const;
    double ScoreTree(MarginalTree &mtree, ScistPerfPhyProbOnTree *pTreeCalc);
    double ScoreTreeMulti(MarginalTree &mtree, ScistPerfPhyProbOnTree *pTreeCalc);
    
    const ScistGenGenotypeMat &genosInput;
    const string &strTreeInit;
    //const ScistPerfPhyGuideTree &treeGuide;
    MarginalTree mtreeOpt;
    double minProbInc;
    int maxIters;
    int numThreads;
    //int maxMultiSPRsMoves;
    bool fHeu;
    double heuFracSPR;
    int thresSPRDrop;
    bool fVerbose;
};

// **************************************************************
// Fast NNI local search

class ScistFastNNILocalSearch
{
public:
    //ScistFastNNILocalSearch(const ScistGenGenotypeMat &genosInputIn, const ScistPerfPhyGuideTree &treeGuideIn, int nt);
    ScistFastNNILocalSearch(const ScistGenGenotypeMat &genosInputIn, const string &treeInitIn, int nt);
    double CalcCurrMaxProb(std::string &strNNIBestTree) const;
    void SetNumThreads(int n) { numThreads = n; }

private:
    double CalcCurrMaxProbMT(std::string &strNNIBestTree) const;
    void Init();
    void InitMT();
    int GetNumSites() const;
    int GetNumCells() const;
    int GetNumNodesInTree() const;
    
    const ScistGenGenotypeMat &genosInput;
    //const ScistPerfPhyGuideTree &treeGuide;
    MarginalTree mtree;
    int numThreads;
    std::vector<std::vector<double> > tblQ;
    //std::vector<double> tblQMax;    // max Q value at sites
    std::vector<std::vector<double> > tblM0;   // tblM0[s][node] = max Q value of nodes in the subtree rooted at node for site s
    std::vector<std::vector<double> > tblM1;   // tblM1[s][node] = max Q value of nodes NOT in the subtree rooted at node for site s
};

// **************************************************************
// Fast re-rooting local search

class ScistFastRerootLocalSearch
{
public:
    ScistFastRerootLocalSearch(const ScistGenGenotypeMat &genosInputIn,
                            const string &strTreeInit, int nt);
    void SetNumThreads(int t) { numThreads = t; }
    void SetInitTree(const MarginalTree &mtreeInit);
    void SetExcludeSTs(const std::set<int> &excSTs) { setSTExcluded = excSTs; }
    //void SetCandSizeLimit(double f) { fracCands = f;}    // set to any size limit f: from 0.0 to number of taxa
    double CalcCurrMaxProb() const;
    void GetCurrTree(MarginalTree &treeOut) const;
    double GetOptSubtreeReroot( int &nodeSTRootNew, int &nodeST );
    double GetOptSubtreeRerootMT( int &nodeSTRootNew, int &nodeST );
    int GetNumSites() const;
    int GetNumCells() const;
    double GetCurrMaxProb() const { return this->logProbCurr; }
    void SetCurrMaxProb(double p) { this->logProbCurr = p; }
    double GetSumLogAllele0Prob() const { return this->sumLogprobAllele0; }
    
    // not really interface functions but for multithreading code...
    double CalcMaxQForReroot(int site, int node, int nodeSub, int rootIndex, int rootSubIndex, int childOtherside, int nodeSubNodeIndex) const;
    double GetQVal(int site, int node) const { return this->tblQ[site][node]; }
    double GetM0Val(int site, int node) const { return this->tblM0[site][node]; }
    bool IsNodeAncestralTo(int node1, int node2) const;
    int GetAncesIndex(int nodeDesc, int nodeAnces) const;
    
private:
    void Init();
    void InitQTbl();
    void InitM0Tbl();
    void InitM1Tbl();
    void InitM1TblMT();
    void InitM2Tbl();
    void InitM2TblMT();
    void InitM4Tbl();
    void InitM4TblMT();
    void InitCandidates();
    int GetNumNodesInTree() const;
    std::string ConsTreeFromSetClusters( const std::set<ScistPerfPhyCluster> &setClusters ) const;
    void CollectRerootCands( );
    int GetNumAncesForNode(int node) const { return mapListAnces[node].size(); }
    
    const ScistGenGenotypeMat &genosInput;
    //const ScistPerfPhyGuideTree &treeGuide;
    const string &strTreeInit;
    MarginalTree mtree;
    int numThreads;
    bool fHeu;
    int thresSPRDropStop;
    double logProbCurr;
    double sumLogprobAllele0;
    std::vector<std::vector<double> > tblQ;
    std::vector<std::vector<double> > tblM0;
    std::vector<std::vector< std::vector<double> > > tblM1;
    std::vector<std::vector< std::vector<double> > > tblM2;
    std::vector<std::vector< std::vector<double> > > tblM4;
    //std::vector<std::vector< std::map<int,double> > > tblM1;
    //std::vector<std::vector< std::map<int,double> > > tblM2;
    //std::vector<std::vector< std::map<int,double> > > tblM4;
    //std::vector<std::vector< std::map<int,double> > > tblM5;
    // helper: decide whether a node is ancestral to a node
    std::vector< set<int> > mapListAnces;
    std::vector< map<int,int> > mapListAncesLookup;     // which index of the ancestor for the particular ancestor to look up
    std::vector<std::pair<int,int> > listCandsReroot;
    std::set<int> setSTExcluded;
    //double fracCands;
};




#endif /* ScistLocalSearch_hpp */
