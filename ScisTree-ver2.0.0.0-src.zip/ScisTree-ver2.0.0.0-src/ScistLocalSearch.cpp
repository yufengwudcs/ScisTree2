//
//  ScistLocalSearch.cpp
//  
//
//  Created by Yufeng Wu on 12/16/22.
//

#include "ScistLocalSearch.hpp"
#include "ScistPerfPhyUtils.hpp"
#include "ScistPerfPhyImp.hpp"
#include "ScistGenotype.hpp"
#include "Utils3.h"
#include "Utils4.h"
#include "TreeBuilder.h"
#include "MarginalTree.h"
#include "RBT.h"
#include "PhylogenyTree.h"
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <thread>
#include "UtilsNumerical.h"

// **************************************************************
// Fast rSPR local search

ScistFastSPRLocalSearch :: ScistFastSPRLocalSearch(const ScistGenGenotypeMat &genosInputIn, /*const ScistPerfPhyGuideTree &treeGuideIn, */ const string &strTreeInitIn, int nt) : genosInput(genosInputIn), //treeGuide(treeGuideIn),
    strTreeInit(strTreeInitIn), numThreads(nt), fHeu(true), fracHeuSPRSrc(1.0), thresSPRDropStop(100)
{
    Init();
//cout << "SPR: initialized.\n";
}

double ScistFastSPRLocalSearch :: CalcCurrMaxProb() const
{
    double probMaxAll = 0.0;
    for(int site=0; site<GetNumSites(); ++site)
    {
        double val = this->tblM0[site][this->mtree.GetRoot()];
        if( val < 0.0 )
        {
            // if no best cut, then we just choose to not to cut
            val = 0.0;
        }
        probMaxAll += val;
    }
    return probMaxAll;
}

void ScistFastSPRLocalSearch :: GetCurrTree(MarginalTree &treeOut) const
{
    treeOut = mtree;
}

double ScistFastSPRLocalSearch :: GetOpt1SPRMove(int &nodeSPRSrc, int &nodeSPRDest, int &nodeLCA, std::vector<double> *pMapMaxProbSrc, std::vector<double> *pMapMaxProbDest, std::map<std::pair<int,int>,double> *pMapSPRVal)
{
    //if( pMapMaxProbSrc != NULL )
    //{
    //    pMapMaxProbSrc->clear();
    //}
    //if( pMapMaxProbDest != NULL )
    //{
    //    pMapMaxProbDest->clear();
    //}
    
    if( this->numThreads > 1 && GetNumNodesInTree() > this->numThreads  )
    {
        //
        return GetOpt1SPRMoveMT(nodeSPRSrc, nodeSPRDest, nodeLCA, pMapMaxProbSrc, pMapMaxProbDest, pMapSPRVal);
    }
//cout << "GetOpt1SPRMove: current tree: " << this->mtree.GetNewickNoBrLen() << endl;
//this->mtree.Dump();
    
    //
    std::vector< set<std::pair<int,int> > > listSPRs;
    CollectAllSPRs(listSPRs);
    
#if 0
    int numTotSPRNgbrs = 0;
    for(vector<set<pair<int,int> > > :: iterator it = listSPRs.begin(); it != listSPRs.end(); ++it)
    {
        numTotSPRNgbrs += it->size();
    }
    cout << "Number of 1-rSPR neighboring trees: " << numTotSPRNgbrs << endl;
#endif
#if 0
    cout << "List of all SPRs: \n";
    for(map<int,set<pair<int,int> > > :: iterator it = listSPRs.begin(); it != listSPRs.end(); ++it)
    {
        cout << "LCA: " << it->first << endl;
        for(set<pair<int,int> > :: iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2)
        {
            cout << "Src: " << it2->first << ",  dest: " << it2->second << endl;
        }
    }
#endif
    
    std::vector<std::pair<int, std::pair<int,int> > > listSPRsOrdered;
    OrderSPRs(listSPRs, listSPRsOrdered);
#if 0
    cout << "List of all ORDERED SPRs: \n";
    for(unsigned int i=0; i< listSPRsOrdered.size(); ++i)
    {
        cout << "LCA: " << listSPRsOrdered[i].first << ", Src: " << listSPRsOrdered[i].second.first << ",  dest: " << listSPRsOrdered[i].second.second << endl;
    }
#endif
    
    vector<double> listProbs;
//cout << "-- sum of log prob of 0s: " << this->sumLogprobAllele0 << endl;
    for(unsigned int i=0; i< listSPRsOrdered.size(); ++i)
    {
        //
        double probMaxStep = this->sumLogprobAllele0;
        int noder = listSPRsOrdered[i].first;
        int nodeu = listSPRsOrdered[i].second.first, nodew = listSPRsOrdered[i].second.second;
        for(int site=0; site<GetNumSites(); ++site)
        {
            double probs = CalcMaxQForSPR(site, noder, nodeu, nodew);
//cout << "Max Q value for SPR: site:" << site << ", noder:" << noder << ", nodeu:" << nodeu << ", nodew:" << nodew << " is " << probs << endl;
            probMaxStep += probs;
        }
//cout << "noder: " << noder << ", nodeu: " << nodeu << ", nodew: " << nodew << ", probMaxStep: " << probMaxStep << endl;
        
        if( pMapMaxProbSrc != NULL )
        {
            //if( pMapMaxProbSrc->find(nodeu) == pMapMaxProbSrc->end() )
            //{
            //    (*pMapMaxProbSrc)[nodeu] = probMaxStep;
            //}
            //else
            if( (*pMapMaxProbSrc)[nodeu] < probMaxStep  )
            {
                (*pMapMaxProbSrc)[nodeu] = probMaxStep;
            }
        }
        if( pMapMaxProbDest != NULL )
        {
            //if( pMapMaxProbDest->find(nodew) == pMapMaxProbDest->end() )
            //{
            //    (*pMapMaxProbDest)[nodew] = probMaxStep;
            //}
            //else
            if( (*pMapMaxProbDest)[nodew] < probMaxStep  )
            {
                (*pMapMaxProbDest)[nodew] = probMaxStep;
            }
        }
        
        listProbs.push_back(probMaxStep);
//cout << "--- max Q value over ALL sites: " << probMaxStep << endl;
    }
    
    // consider all rSPR move
    double probMax = MAX_NEG_DOUBLE_VAL;
    nodeSPRSrc = -1;
    nodeSPRDest = -1;
    nodeLCA = -1;
    // find the best move
    for(unsigned int i=0; i<listSPRsOrdered.size(); ++i)
    {
        double probMaxStep = listProbs[i];
        int noder = listSPRsOrdered[i].first;
        int nodeu = listSPRsOrdered[i].second.first, nodew = listSPRsOrdered[i].second.second;
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeSPRSrc = nodeu;
            nodeSPRDest = nodew;
            nodeLCA = noder;
        }
        if( pMapSPRVal != NULL )
        {
            pair<int,int> pp(nodeu, nodew);
            (*pMapSPRVal)[pp] = probMaxStep;
        }
    }

    // if fail to find SPR, just return the smallest
    if( nodeSPRSrc < 0 || nodeSPRDest < 0 || nodeLCA < 0 )
    {
        cout << "Warning: fail to find 1-SPR move. \n";
        return MAX_NEG_DOUBLE_VAL;
    }
    
    YW_ASSERT_INFO(nodeSPRSrc >= 0 && nodeSPRDest >=0 && nodeLCA >=0, "Fail to find optimal SPR");
//cout << "***** Max prob of one SPR move: " << probMax << ", nodeSPRSrc:" << nodeSPRSrc << ", nodeSPRDest:" << nodeSPRDest << endl;
    //
    return probMax;
}

static void UtilFastSPRSearch( ScistFastSPRLocalSearch *pthis, int tindex, const std::vector<std::pair<int, std::pair<int,int> > > *plistSPRsOrdered, unsigned int posStart, unsigned int posEnd, vector<double> *pListProb, vector<int> *pListSrc, vector<int> *pListDest, vector<int> *pListLCA, double sumLogprobAllele0, std::vector<double> *pMapMaxProbSrc, std::vector<double> *pMapMaxProbDest )
{
    double probMax = MAX_NEG_DOUBLE_VAL;
    int nodeSPRSrc = -1;
    int nodeSPRDest = -1;
    int nodeLCA = -1;
    for(unsigned int i=posStart; i<= posEnd; ++i)
    {
        //
        double probMaxStep = sumLogprobAllele0;
        int noder = (*plistSPRsOrdered)[i].first;
        int nodeu = (*plistSPRsOrdered)[i].second.first, nodew = (*plistSPRsOrdered)[i].second.second;
        for(int site=0; site<pthis->GetNumSites(); ++site)
        {
            double probs = pthis->CalcMaxQForSPR(site, noder, nodeu, nodew);
//cout << "Max Q value for SPR: site:" << site << ", noder:" << noder << ", nodeu:" << nodeu << ", nodew:" << nodew << " is " << probs << endl;
            probMaxStep += probs;
        }
//cout << "--- max Q value over ALL sites: " << probMaxStep << endl;
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeSPRSrc = nodeu;
            nodeSPRDest = nodew;
            nodeLCA = noder;
        }
        
        if( pMapMaxProbSrc != NULL )
        {
            //if( pMapMaxProbSrc->find(nodeu) == pMapMaxProbSrc->end() )
            //{
            //    (*pMapMaxProbSrc)[nodeu] = probMaxStep;
            //}
            //else
            if( (*pMapMaxProbSrc)[nodeu] < probMaxStep  )
            {
                (*pMapMaxProbSrc)[nodeu] = probMaxStep;
            }
        }
        if( pMapMaxProbDest != NULL )
        {
            //if( pMapMaxProbDest->find(nodew) == pMapMaxProbDest->end() )
            //{
            //    (*pMapMaxProbDest)[nodew] = probMaxStep;
            //}
            //else
            if( (*pMapMaxProbDest)[nodew] < probMaxStep  )
            {
                (*pMapMaxProbDest)[nodew] = probMaxStep;
            }
        }
    }
    // save results
    (*pListProb)[tindex] = probMax;
    (*pListSrc)[tindex] = nodeSPRSrc;
    (*pListDest)[tindex] = nodeSPRDest;
    (*pListLCA)[tindex] = nodeLCA;
}

double ScistFastSPRLocalSearch :: GetOpt1SPRMoveMT(int &nodeSPRSrc, int &nodeSPRDest, int &nodeLCA, std::vector<double> *pMapMaxProbSrc, std::vector<double> *pMapMaxProbDest, std::map<std::pair<int,int>,double> *pMapSPRVal  )
{
    //
    std::vector< set<std::pair<int,int> > > listSPRs;
    CollectAllSPRs(listSPRs);
#if 0
    cout << "List of all SPRs: \n";
    for(map<int,set<pair<int,int> > > :: iterator it = listSPRs.begin(); it != listSPRs.end(); ++it)
    {
        cout << "LCA: " << it->first << endl;
        for(set<pair<int,int> > :: iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2)
        {
            cout << "Src: " << it2->first << ",  dest: " << it2->second << endl;
        }
    }
#endif
    
    std::vector<std::pair<int, std::pair<int,int> > > listSPRsOrdered;
    OrderSPRs(listSPRs, listSPRsOrdered);
#if 0
    cout << "List of all ORDERED SPRs: \n";
    for(unsigned int i=0; i< listSPRsOrdered.size(); ++i)
    {
        cout << "LCA: " << listSPRsOrdered[i].first << ", Src: " << listSPRsOrdered[i].second.first << ",  dest: " << listSPRsOrdered[i].second.second << endl;
    }
#endif
    
    // do multi-threading
//cout << "Start multi-threading...\n";
    int numThreadsUse = numThreads;
    if( (int)listSPRsOrdered.size() < numThreadsUse )
    {
        numThreadsUse = (int)listSPRsOrdered.size();
    }
    vector<double> listProbs(numThreadsUse);
    vector<int> listSrcs(numThreadsUse);
    vector<int> listDests(numThreadsUse);
    vector<int> listLCAs(numThreadsUse);
    int numItems = listSPRsOrdered.size();
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilFastSPRSearch, this, t, &listSPRsOrdered, blkStart, blkEnd, &listProbs, &listSrcs, &listDests, &listLCAs, this->sumLogprobAllele0, pMapMaxProbSrc, pMapMaxProbDest );
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "End opt SPR search multi-threading...\n";
    // consider all rSPR move
    double probMax = MAX_NEG_DOUBLE_VAL;
    nodeSPRSrc = -1;
    nodeSPRDest = -1;
    nodeLCA = -1;
    for(unsigned int i=0; i< listProbs.size(); ++i)
    {
//cout << "--- max Q value over ALL sites: " << probMaxStep << endl;
        if( listProbs[i] > probMax )
        {
            probMax = listProbs[i];
            nodeSPRSrc = listSrcs[i];
            nodeSPRDest = listDests[i];
            nodeLCA = listLCAs[i];
        }
        if( pMapSPRVal != NULL )
        {
            pair<int,int> pp(listSrcs[i], listDests[i]);
            (*pMapSPRVal)[pp] = listProbs[i];
        }
    }
    
    // if fail to find SPR, just return the smallest
    if( nodeSPRSrc < 0 || nodeSPRDest < 0 || nodeLCA < 0 )
    {
        cout << "Warning: fail to find 1-SPR move. \n";
        return MAX_NEG_DOUBLE_VAL;
    }
    
    YW_ASSERT_INFO(nodeSPRSrc >= 0 && nodeSPRDest >=0 && nodeLCA >=0, "Fail to find optimal SPR");
//cout << "***** Max prob of one SPR move: " << probMax << ", nodeSPRSrc:" << nodeSPRSrc << ", nodeSPRDest:" << nodeSPRDest << endl;
    //
    //return probMax + this->sumLogprobAllele0;
    return probMax;
}

double ScistFastSPRLocalSearch :: GetOptSubtreeReroot( int &nodeSTRootNew, int &nodeST )
{
    // Init tblM4 first
    InitM4Tbl();
    
    if( this->numThreads > 1 && GetNumNodesInTree() > this->numThreads  )
    {
        //
        return GetOptSubtreeRerootMT(nodeSTRootNew, nodeST);
    }
//cout << "GetOptSubtreeReroot: sum of prob 0: " << this->sumLogprobAllele0 << endl;
//cout << "tree: ";
//mtree.Dump();
#if 0
    // collect M4[s][nodeu][noder] = max partial sum of off-path [noder->nodeu] Q values
    // now collect M4
    vector<vector<map<int,double> > > tblM4( GetNumSites() );
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        tblM4[site].resize(mtree.GetTotNodesNum());
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            tblM4[site][node][node] = 0;
            // trace up until reaching the root
            int nodeCurr = node;
            int nodeAnces = mtree.GetParent(node);
            tblM4[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = mtree.GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    int nodeSib = mtree.GetSibling(nodeCurr);
                    tblM4[site][node][nodeAncesAnces] = std::max( tblM4[site][node][nodeAnces] + this->tblQ[site][nodeSib], this->tblQ[site][nodeSib]);
                    //cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeCurr = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
    //cout << "Done with computing M4\n";
#endif
    
    
    // nodeST: the subtree; nodeSTRootNew: a descedant node of nodeST which is the new root
    // best way of rotating the subtree at nodeST so that the resulting Q is max
    vector<pair<int,int> > listRerootCands;
    for(unsigned int i=0; i<mapListAnces.size(); ++i)
    {
        int nodeSub = i;
        for(set<int> :: iterator it = mapListAnces[i].begin(); it != mapListAnces[i].end(); ++it)
        {
            int node = *it;
            // skip if nodeSub is direct desendant of node
            if( node == nodeSub || mtree.GetParent(nodeSub) == node )
            {
                continue;
            }
            pair<int,int> pp(nodeSub, node);
            listRerootCands.push_back(pp);
        }
    }
    vector<double> listProbs( listRerootCands.size() );
    for(unsigned int i=0; i< listRerootCands.size(); ++i)
    {
        //
        int nodeSub = listRerootCands[i].first, node = listRerootCands[i].second;
        
        //
        double probMaxStep = this->sumLogprobAllele0;
        for(int site=0; site<GetNumSites(); ++site)
        {
            double probs = CalcMaxQForReroot(site, node, nodeSub);
//cout << "Max Q value for reroot: site:" << site << ", node:" << node << ", nodeSub:" << nodeSub << " is " << probs << endl;
            probMaxStep += probs;
        }
//cout << "noder: " << noder << ", nodeu: " << nodeu << ", nodew: " << nodew << ", probMaxStep: " << probMaxStep << endl;
        listProbs[i] = probMaxStep;
//cout << "Reroot: node:" << node << ", nodeSub:" << nodeSub << " --- max Q value over ALL sites: " << probMaxStep << endl;
    }
    
    // consider all rSPR move
    double probMax = MAX_NEG_DOUBLE_VAL;
    nodeSTRootNew = -1;
    nodeST = -1;
    // find the best move
    for(unsigned int i=0; i<listRerootCands.size(); ++i)
    {
        double probMaxStep = listProbs[i];
        int nodeu = listRerootCands[i].first;
        int noder = listRerootCands[i].second;
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeSTRootNew = nodeu;
            nodeST = noder;
        }
    }
    
    // if fail to find SPR, just return the smallest
    if( nodeSTRootNew < 0 || nodeST < 0 )
    {
        cout << "Warning: fail to find re-rootiing move. \n";
        return MAX_NEG_DOUBLE_VAL;
    }
    
//cout << "^^^^^^ Max prob of one rerooting move: " << probMax << ", subtree rooted at:" << nodeST << ", to a new node (within the subtree):" << nodeSTRootNew << endl;
    //
    return probMax;
}
    
static void UtilFastRerootSearch( ScistFastSPRLocalSearch *pthis, int tindex, const std::vector<std::pair<int, int> > *plistRerootCand, unsigned int posStart, unsigned int posEnd, vector<double> *pListProb, vector<int> *pListNodes, vector<int> *pListNodeSTs, double sumLogprobAllele0 )
{
    double probMax = MAX_NEG_DOUBLE_VAL;
    int nodeBest = -1;
    int nodeSTBest = -1;
    
    for(unsigned int i=posStart; i<= posEnd; ++i)
    {
        //
        double probMaxStep = sumLogprobAllele0;
        int nodeSubStep = (*plistRerootCand)[i].first, nodeStep = (*plistRerootCand)[i].second;
        for(int site=0; site<pthis->GetNumSites(); ++site)
        {
            double probs = pthis->CalcMaxQForReroot(site, nodeStep, nodeSubStep);
//cout << "Max Q value for SPR: site:" << site << ", noder:" << noder << ", nodeu:" << nodeu << ", nodew:" << nodew << " is " << probs << endl;
            probMaxStep += probs;
        }
//cout << "--- max Q value over ALL sites: " << probMaxStep << endl;
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeBest = nodeStep;
            nodeSTBest = nodeSubStep;
        }
    }
    // save results
    (*pListProb)[tindex] = probMax;
    (*pListNodes)[tindex] = nodeBest;
    (*pListNodeSTs)[tindex] = nodeSTBest;
}

double ScistFastSPRLocalSearch :: GetOptSubtreeRerootMT( int &nodeSTRootNew, int &nodeST )
{
    // do multi-threading
//cout << "Start multi-threading...\n";
    
    
    // nodeST: the subtree; nodeSTRootNew: a descedant node of nodeST which is the new root
    // best way of rotating the subtree at nodeST so that the resulting Q is max
    vector<pair<int,int> > listRerootCands;
    for(unsigned int i=0; i<mapListAnces.size(); ++i)
    {
        int nodeSub = i;
        for(set<int> :: iterator it = mapListAnces[i].begin(); it != mapListAnces[i].end(); ++it)
        {
            int node = *it;
            // skip if nodeSub is direct desendant of node
            if( node == nodeSub || mtree.GetParent(nodeSub) == node )
            {
                continue;
            }
            pair<int,int> pp(nodeSub, node);
            listRerootCands.push_back(pp);
        }
    }
    int numThreadsUse = numThreads;
    if( (int)listRerootCands.size() < numThreadsUse )
    {
        numThreadsUse = (int)listRerootCands.size();
    }
    
//cout << "Number of re-rooting candidates: " << listRerootCands.size() << endl;
    
    vector<double> listProbs(numThreadsUse);
    vector<int> listNodes(numThreadsUse);
    vector<int> listNodeSTs(numThreadsUse);
    int numItems = listRerootCands.size();
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilFastRerootSearch, this, t, &listRerootCands, blkStart, blkEnd, &listProbs, &listNodes, &listNodeSTs, this->sumLogprobAllele0 );
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
    
    // consider all rSPR move
    double probMax = MAX_NEG_DOUBLE_VAL;
    nodeSTRootNew = -1;
    nodeST = -1;
    // find the best move
    for(unsigned int i=0; i<listProbs.size(); ++i)
    {
        double probMaxStep = listProbs[i];
        int node = listNodes[i];
        int nodes = listNodeSTs[i];
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeSTRootNew = nodes;
            nodeST = node;
        }
    }
    
    // if fail to find SPR, just return the smallest
    if( nodeSTRootNew < 0 || nodeST < 0 )
    {
        cout << "Warning: fail to find re-rootiing move. \n";
        return MAX_NEG_DOUBLE_VAL;
    }
    
//cout << "^^^^^^ Max prob of one rerooting move: " << probMax << ", subtree rooted at:" << nodeST << ", to a new node (within the subtree):" << nodeSTRootNew << endl;
    //
    return probMax;
}


// initialization code
void ScistFastSPRLocalSearch :: Init()
{
//cout << "ScistFastSPRLocalSearch :: Init()\n";
    // construct marg tree to work with
    //set<ScistPerfPhyCluster> setClusAllGuide;
    //this->treeGuide.GetAllClusters( setClusAllGuide );
//cout << "Number of clusters: " << setClusAllGuide.size() << endl;
    //string strTree = ConsTreeFromSetClusters( setClusAllGuide );
    //string strTree = this->treeGuide.GetInitTree();
    string strTree = this->strTreeInit;
//cout << "Initial tree: " << strTree << endl;
    ReadinMarginalTreesNewickWLenString(strTree, GetNumCells(), mtree);
    //cout << "Marginal tree: ";
    //mtree.Dump();
    
    SetInitTree(mtree);
}

void ScistFastSPRLocalSearch :: SetInitTree(const MarginalTree &mtreeInit)
{
    this->mtree = mtreeInit;
    // initialize ancestral relations
    mapListAnces.clear();
    mapListAnces.resize( mtree.GetTotNodesNum() );
    for(int node=0; node<mtree.GetTotNodesNum(); ++node)
    {
        int nodeAnces = node;
        set<int> ss;
        while(true)
        {
            ss.insert(nodeAnces);
            if( mtree.GetRoot() == nodeAnces)
            {
                break;
            }
            else
            {
                nodeAnces = mtree.GetParent(nodeAnces);
            }
        }
        mapListAnces[node] = ss;
    }
//cout << "Now initialize tables\n";
    InitQTbl();
    if( listEdgeCandidacy.size() == 0 )
    {
        InitCandidates();
    }
    InitM0Tbl();
    InitM1Tbl();
    InitM2Tbl();
    
    // init prob
    this->sumLogprobAllele0 = this->genosInput.CalcSumLogProbAllele0All();
    this->logProbCurr = CalcCurrMaxProb();
    this->logProbCurr += this->sumLogprobAllele0;
}
void ScistFastSPRLocalSearch :: InitQTbl()
{
    this->tblQ.clear();
    this->tblQ.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblQ[s].resize( mtree.GetTotNodesNum() );
    }
    //
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "InitQTbl: site:" << site << endl;
        // do a bottom up
        vector<double> listNodeSplitProb;
        // init to be bad
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            listNodeSplitProb.push_back( -1.0*HAP_MAX_INT );
        }
        
    //cout << "CalcProbMaxForSiteHap: mtree: " << mtree.GetNewickSorted(false) << endl;
    //mtree.Dump();
        
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            //cout << "node " << node << endl;
            double logpStep = 0.0;
            if( mtree.IsLeaf(node) )
            {
                // a single leaf in the split
                int lvlbl = mtree.GetLabel(node)-1;
                //cout << "Leaf: " << lvlbl << endl;
                double p0 = this->genosInput.GetGenotypeProbAllele0At(lvlbl, site);
                if( p0 < YW_VERY_SMALL_FRACTION)
                {
                    p0 = YW_VERY_SMALL_FRACTION;
                }
                else if( p0 > 1.0-YW_VERY_SMALL_FRACTION)
                {
                    p0 = 1.0-YW_VERY_SMALL_FRACTION;
                }
                logpStep = log((1-p0)/p0);
    //cout << "Set leaf " << node << " log prob to: " << logpStep << ", p0=" << p0 << endl;
            }
            else
            {
                // get the two children and add them up
                int childLeft = mtree.GetLeftDescendant(node);
                int childRight = mtree.GetRightDescendant(node);
    //cout << "node: " << node << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
                //cout << "childLeft: " << childLeft << ", right: " << childRight << endl;
                
                YW_ASSERT_INFO( listNodeSplitProb[childLeft] > -1.0*HAP_MAX_INT, "Bad left-a" );
                YW_ASSERT_INFO( listNodeSplitProb[childRight] > -1.0*HAP_MAX_INT, "Bad right1-a" );
                logpStep = listNodeSplitProb[childLeft] + listNodeSplitProb[childRight];
            }
//cout << "log prob: " << logpStep << " for node: " << node << endl;
            listNodeSplitProb[node] = logpStep;
        }
        
        // save the probs
        this->tblQ[site] = listNodeSplitProb;
    }
}
void ScistFastSPRLocalSearch :: InitCandidates()
{
    listEdgeCandidacy.resize( GetNumNodesInTree() );
    for(int i=0; i<GetNumNodesInTree(); ++i)
    {
        // by default, each edge can perform rSPR
        listEdgeCandidacy[i] = true;
    }
    if( fHeu == false )
    {
        return;
    }
    // only allow leaves
    for(int i=GetNumCells(); i<GetNumNodesInTree(); ++i)
    {
        listEdgeCandidacy[i] = false;
    }
    
    // Now destination
    listEdgeCandidacyDest.resize( GetNumNodesInTree() );
    for(int i=0; i<GetNumNodesInTree(); ++i)
    {
        listEdgeCandidacyDest[i] = true;
    }
}
void ScistFastSPRLocalSearch :: InitM0Tbl()
{
//cout << "InitM0Tbl: " << endl;
    // collect the maximum Q values of each subtree
    this->tblM0.clear();
    this->tblM0.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM0[s].resize( mtree.GetTotNodesNum() );
    }
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            if( mtree.IsLeaf(node) )
            {
                // a single leaf in the split
                tblM0[site][node] = tblQ[site][node];
            }
            else
            {
                // get the two children and add them up
                int childLeft = mtree.GetLeftDescendant(node);
                int childRight = mtree.GetRightDescendant(node);
    //cout << "node: " << node << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
                //cout << "childLeft: " << childLeft << ", right: " << childRight << endl;
                
                YW_ASSERT_INFO( tblM0[site][childLeft] > -1.0*HAP_MAX_INT, "Bad left-b" );
                YW_ASSERT_INFO( tblM0[site][childRight] > -1.0*HAP_MAX_INT, "Bad right1-b" );
                double probM0 = std::max(tblM0[site][childLeft], tblM0[site][childRight]);
                tblM0[site][node] = std::max(probM0, tblQ[site][node]);
            }
//cout << "Set tblM0: site:" << site << ", node:" << node << ", to: " << tblM0[site][node] << endl;
        }
    }
}
void ScistFastSPRLocalSearch :: InitM1Tbl()
{
    //if( this->numThreads > 1 && GetNumSites() > this->numThreads )
    if( this->numThreads > 1 )
    {
        InitM1TblMT();
        return;
    }
    this->tblM1.clear();
    this->tblM1.resize( GetNumSites() );
//cout << "InitM1Tbl: " << endl;
    // first iterate over sites
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        this->tblM1[site].resize(mtree.GetTotNodesNum());
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            // trace up until reaching the root
            int nodeAnces = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                this->tblM1[site][node][nodeAnces] = probMaxPath;
//cout << "Set tblM1: site:" << site << ", node:" << node << ", nodeAnces: " << nodeAnces << ", to: " << tblM1[site][node][nodeAnces] << endl;
                double prob2 = this->tblQ[site][nodeAnces];
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
                
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
}

// muliti-threading
static void UtilsInitM1Tbl( ScistFastSPRLocalSearch *pthis, MarginalTree *ptree, int posStart, int posEnd, std::vector<std::vector< std::map<int,double> > > *pTblM1 )
{
    // first iterate over sites
    for(int site=posStart; site<=posEnd; ++site)
    {
        // do iteration over each node from bottom up
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            // trace up until reaching the root
            int nodeAnces = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                (*pTblM1)[site][node][nodeAnces] = probMaxPath;
//cout << "Set tblM1: site:" << site << ", node:" << node << ", nodeAnces: " << nodeAnces << ", to: " << tblM1[site][node][nodeAnces] << endl;
                double prob2 = pthis->GetQVal(site, nodeAnces);
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
                if( nodeAnces == ptree->GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAnces = ptree->GetParent(nodeAnces);
                }
            }
        }
    }
}
void ScistFastSPRLocalSearch :: InitM1TblMT()
{
//cout << "InitM1TblMT:\n";
    this->tblM1.clear();
    this->tblM1.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM1[s].resize(  GetNumNodesInTree() );
    }

    int numItems = GetNumSites();
    int blkSize = numItems/this->numThreads;
    int blkStart = 0;
    int numThreadsUse = this->numThreads;
    if( this->numThreads > GetNumSites() )
    {
        numThreadsUse = GetNumSites();
    }
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitM1Tbl, this, &mtree, blkStart, blkEnd, &tblM1);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "InitM1TblMT: multithreading done\n";
}

void ScistFastSPRLocalSearch :: InitM2Tbl()
{
    if( this->numThreads > 1 )
    {
        InitM2TblMT();
        return;
    }
//cout << "^^^^^^^Init M2:\n";
    this->tblM2.clear();
    this->tblM2.resize( GetNumSites() );

    // first iterate over sites
    for(int site=0; site<GetNumSites(); ++site)
    {
        this->tblM2[site].resize(mtree.GetTotNodesNum());
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            if( node == mtree.GetRoot() )
            {
                continue;
            }
            
            // trace up until reaching the root
            int nodeAnces = mtree.GetParent( node );
            int nodeAncesBelow = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                this->tblM2[site][node][nodeAnces] = probMaxPath;
//cout << "set M2: node:" << node << ", nodeAnces: " << nodeAnces << " to : " << probMaxPath << endl;
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAncesBelow = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
                // get the side chain at nodeAnces
                int nodeSide = mtree.GetLeftDescendant(nodeAncesBelow);
                if( IsNodeAncestralTo( nodeSide, node) )
                {
                    nodeSide = mtree.GetRightDescendant(nodeAncesBelow);
                }
                //YW_ASSERT_INFO(nodeSide != nodeAncesBelow, "Fail to find side chain node");
//cout << "nodeside:" << nodeSide << ", node: " << node << ", M0: at side node: " << this->tblM0[site][nodeSide] << endl;
                
                double prob2 = this->tblM0[site][nodeSide];
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
            }
        }
    }
}

// multi-threading
static void UtilsInitM2Tbl(ScistFastSPRLocalSearch *pthis, MarginalTree *ptree, int posStart, int posEnd, std::vector<std::vector< std::map<int,double> > > *pTblM2)
{
    // first iterate over sites
    for(int site=posStart; site<=posEnd; ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            if( node == ptree->GetRoot() )
            {
                continue;
            }
            
            // trace up until reaching the root
            int nodeAnces = ptree->GetParent( node );
            int nodeAncesBelow = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                (*pTblM2)[site][node][nodeAnces] = probMaxPath;
//cout << "set M2: node:" << node << ", nodeAnces: " << nodeAnces << " to : " << probMaxPath << endl;
                if( nodeAnces == ptree->GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAncesBelow = nodeAnces;
                    nodeAnces = ptree->GetParent(nodeAnces);
                }
                // get the side chain at nodeAnces
                int nodeSide = ptree->GetLeftDescendant(nodeAncesBelow);
                if( pthis->IsNodeAncestralTo( nodeSide, node) )
                {
                    nodeSide = ptree->GetRightDescendant(nodeAncesBelow);
                }
                //YW_ASSERT_INFO(nodeSide != nodeAncesBelow, "Fail to find side chain node");
//cout << "nodeside:" << nodeSide << ", node: " << node << ", M0: at side node: " << this->tblM0[site][nodeSide] << endl;
                
                double prob2 = pthis->GetM0Val(site, nodeSide);
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
            }
        }
    }
}

void ScistFastSPRLocalSearch :: InitM2TblMT()
{
//cout << "^^^^^^^Init M2:\n";
    this->tblM2.clear();
    this->tblM2.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM2[s].resize( GetNumNodesInTree() );
    }

    int numItems = GetNumSites();
    int numThreadsUse = this->numThreads;
    if( numThreadsUse > numItems )
    {
        numThreadsUse = numItems;
    }
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitM2Tbl, this, &mtree, blkStart, blkEnd, &tblM2);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "InitM2TblMT: multithreading done\n";
}

void ScistFastSPRLocalSearch :: InitM4Tbl()
{
    tblM4.clear();
    this->tblM4.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM4[s].resize( GetNumNodesInTree() );
    }
    /*tblM5.clear();
    this->tblM5.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM5[s].resize( GetNumNodesInTree() );
    }*/
    
    if( this->numThreads > 1 )
    {
        InitM4TblMT();
        return;
    }
    /*
    // collect M4[s][nodeu][noder] = max partial sum of off-path [noder->nodeu] Q values
    // first collect M5 which is the sum of the prob along the sidechain
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            tblM5[site][node][node] = 0;
            // trace up until reaching the root
            int nodeCurr = node;
            int nodeAnces = mtree.GetParent(node);
            tblM5[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = mtree.GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    int nodeSib = mtree.GetSibling(nodeCurr);
                    tblM5[site][node][nodeAncesAnces] =  tblM5[site][node][nodeAnces] + this->tblQ[site][nodeSib];
//cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeCurr = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
//cout << "Step1\n";
    // now collect M4 which is the max of the prob along the sidechain
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            tblM4[site][node][node] = 0;
            // trace up until reaching the root
            //int nodeCurr = node;
            int nodeAnces = mtree.GetParent(node);
            tblM4[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = mtree.GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    //int nodeSib = mtree.GetSibling(nodeCurr);
                    tblM4[site][node][nodeAncesAnces] = std::max( tblM4[site][node][nodeAnces], tblM5[site][node][nodeAncesAnces]);
//cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    //nodeCurr = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
//cout << "Step2\n";
     */
    
    // collect M4[s][nodeu][noder] = max partial sum of off-path [noder->nodeu] Q values
    // now collect M4
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            tblM4[site][node][node] = 0;
            // trace up until reaching the root
            int nodeCurr = node;
            int nodeAnces = mtree.GetParent(node);
            tblM4[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = mtree.GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    int nodeSib = mtree.GetSibling(nodeCurr);
                    tblM4[site][node][nodeAncesAnces] = std::max( tblM4[site][node][nodeAnces] + this->tblQ[site][nodeSib], this->tblQ[site][nodeSib]);
//cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeCurr = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
    //cout << "Done with tblM4 init.\n";
}

// multi-threading
static void UtilsInitM4Tbl(ScistFastSPRLocalSearch *pthis, MarginalTree *ptree, int posStart, int posEnd, std::vector<std::vector< std::map<int,double> > > *pTblM4)
{
    // first iterate over sites
    for(int site=posStart; site<=posEnd; ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            (*pTblM4)[site][node][node] = 0;
            // trace up until reaching the root
            int nodeCurr = node;
            int nodeAnces = ptree->GetParent(node);
            (*pTblM4)[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = ptree->GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    int nodeSib = ptree->GetSibling(nodeCurr);
                    double prob2 = pthis->GetQVal(site, nodeSib);
                    (*pTblM4)[site][node][nodeAncesAnces] = std::max( (*pTblM4)[site][node][nodeAnces] + prob2, prob2 );
                    //cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == ptree->GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeCurr = nodeAnces;
                    nodeAnces = ptree->GetParent(nodeAnces);
                }
            }
        }
    }
}


void ScistFastSPRLocalSearch :: InitM4TblMT()
{
    int numItems = GetNumSites();
    int numThreadsUse = this->numThreads;
    if( numThreadsUse > numItems )
    {
        numThreadsUse = numItems;
    }
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
//cout << "InitM4TblMT : numThresuse: " << numThreadsUse << ", blk size: " << blkSize << endl;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitM4Tbl, this, &mtree, blkStart, blkEnd, &tblM4);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "Done with InitM4TblMT\n";
}

//*************************************************************
bool ScistFastSPRLocalSearch :: IsNodeAncestralTo(int node1, int node2) const
{
    // is node1 ancestral to node2?
    //map<int, set<int> > :: const_iterator it1 = mapListAnces.find(node2);
    //return it1->second.find(node1) != it1->second.end();
    return mapListAnces[node2].find(node1) != mapListAnces[node2].end();
}

int ScistFastSPRLocalSearch :: GetNumSites() const
{
    return genosInput.GetNumSites();
}
int ScistFastSPRLocalSearch :: GetNumCells() const
{
    return genosInput.GetNumHaps();
}
int ScistFastSPRLocalSearch :: GetNumNodesInTree() const
{
    return 2*GetNumCells()-1;
}
std::string ScistFastSPRLocalSearch :: ConsTreeFromSetClusters( const std::set<ScistPerfPhyCluster> &setClusters ) const
{
    //
    // now construct tree
    ScistInfPerfPhyUtils treeBuild;
    map<int, ScistPerfPhyCluster> mapPickedClus;
    int s = 0;
    for(set<ScistPerfPhyCluster>:: iterator it = setClusters.begin(); it != setClusters.end(); ++it)
    {
        mapPickedClus[s] = *it;
        ++s;
    }
    string strTree = treeBuild.ConsTreeWCombDistClus( this->genosInput, mapPickedClus );
    return strTree;
}

// format: (LCA, (source of SPR, dest of SPR))
void ScistFastSPRLocalSearch :: CollectAllSPRs(std::vector< set<std::pair<int,int> > > &listSPRs)
{
    ReduceCandidateSrcs();
    
#if 0
    int numEdgeCandidates = 0;
    for(unsigned int i=0; i<listEdgeCandidacy.size(); ++i)
    {
        if( listEdgeCandidacy[i] )
        {
            ++numEdgeCandidates;
        }
    }
    cout << "Number of rSPR candidate edge: " << numEdgeCandidates << endl;
#endif
    //
    listSPRs.clear();
    listSPRs.resize( GetNumNodesInTree() );
    // collect all subtree info
    vector< set<int> > listSTLeft, listSTRight;
    listSTLeft.resize(mtree.GetTotNodesNum());
    listSTRight.resize(mtree.GetTotNodesNum());
    for(int node=0; node<mtree.GetTotNodesNum(); ++node)
    {
        if( mtree.IsLeaf(node))
        {
            continue;
        }
        int childLeft = mtree.GetLeftDescendant(node);
        int childRight = mtree.GetRightDescendant(node);
        set<int> ss1 = listSTLeft[childLeft];
        UnionSets(ss1, listSTRight[childLeft]);
        ss1.insert(childLeft);
        listSTLeft[node] = ss1;
        set<int> ss2 = listSTLeft[childRight];
        UnionSets(ss2, listSTRight[childRight]);
        ss2.insert(childRight);
        listSTRight[node] = ss2;
    }
    //
    for(int noder=0; noder<mtree.GetTotNodesNum(); ++noder)
    {
        // prune some node on the left and regraft to the right
        for(set<int> :: iterator it1 = listSTLeft[noder].begin(); it1 != listSTLeft[noder].end(); ++it1 )
        {
            int node1 = *it1;
            if(  node1 == noder )
            {
                continue;
            }
            
            for(set<int> :: iterator it2 = listSTRight[noder].begin(); it2 != listSTRight[noder].end(); ++it2 )
            {
                int node2 = *it2;
                if( node2 == noder )
                {
                    continue;
                }
                // donot allow siblings
                if( mtree.GetSibling(node1) == node2)
                {
                    continue;
                }
                    
                
                pair<int,int> pp1(node1, node2), pp2(node2, node1);
                if( fHeu == false || ( listEdgeCandidacy[node1] == true && listEdgeCandidacyDest[node2] )  )
                {
                    listSPRs[noder].insert(pp1);
                }
                if( fHeu == false || ( listEdgeCandidacy[node2] == true && listEdgeCandidacyDest[node1] ) )
                {
                    listSPRs[noder].insert(pp2);
                }
            }
        }
    }
}

int ScistFastSPRLocalSearch :: GetNumAllowedSPRSrcs() const
{
    int res = 0;
    for(unsigned int i=0; i<listEdgeCandidacy.size(); ++i)
    {
        if( listEdgeCandidacy[i] )
        {
            ++res;
        }
    }
    return res;
}

void ScistFastSPRLocalSearch :: ReduceCandidateSrcs()
{
    // mark some SPR source nodes to discard so to speedup
    if( fracHeuSPRSrc >= 1.0 )
    {
        return;
    }
    // find out num of allowed rSPR src
    int numAllowedSPRSrcs = GetNumAllowedSPRSrcs();
    
    int maxNumKeep = (int)(numAllowedSPRSrcs*fracHeuSPRSrc);
    // ensure there is a minimum
    if(maxNumKeep < thresSPRDropStop)
    {
        maxNumKeep = thresSPRDropStop;
    }
    if( numAllowedSPRSrcs <= maxNumKeep )
    {
        return;
    }
    
    // evaluate the Q value of each leaf; count those whose parent's Q value is negative
    // prefer those src leaves to those with maximum negative parental Q values
    vector<int> listParQValForLeaf( GetNumCells() );
    for(int c=0; c<GetNumCells(); ++c)
    {
        listParQValForLeaf[c] = 0;
    }
    for(int site=0; site<GetNumSites(); ++site)
    {
        //
        for(int c=0; c<GetNumCells(); ++c)
        {
            int par = mtree.GetParent(c);
            YW_ASSERT_INFO( par >=0, "WRONG!" );
            if( this->tblQ[site][par] < 0.0 )
            {
                ++listParQValForLeaf[c];
            }
        }
    }
    vector<pair<int,int> > listPPs;
    for(unsigned int i=0; i<listParQValForLeaf.size(); ++i)
    {
        if( listEdgeCandidacy[i] )
        {
            listPPs.push_back( std::make_pair( listParQValForLeaf[i], i ) );
        }
    }
    std::sort( listPPs.begin(), listPPs.end() );
    
    // mark those socred low to be false
    int numMarkedOff = 0;
    for( unsigned int i=0; i<listPPs.size(); ++i )
    {
        int leaf = listPPs[i].second;
        if( listEdgeCandidacy[leaf] )
        {
            listEdgeCandidacy[leaf] = false;
            ++numMarkedOff;
        }
        
        if( numMarkedOff + maxNumKeep >= numAllowedSPRSrcs )
        {
            break;
        }
    }
}

void ScistFastSPRLocalSearch :: OrderSPRs(const std::vector< set<std::pair<int,int> > > &listSPRs, std::vector<std::pair<int, std::pair<int,int> > > &listSPRsOrdered) const
{
    // get path length info of the current tree
    std::map<int, std::map<int, int> > mapNodeDistToAnces;
    mtree.CollectNumEdgesToAnces(mapNodeDistToAnces);
#if 0
    cout << "-----Node distances:\n";
    for(auto it = mapNodeDistToAnces.begin(); it!=mapNodeDistToAnces.end(); ++it)
    {
        for(auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
        {
            cout << it->first << "  " << it2->first << ":  " << it2->second << endl;
        }
    }
#endif
    
    // order SPRs by preferring the closer branches
    map<int, set<pair<int, pair<int,int> > > > mapRankedSPRs;
    int nodeLCA = 0;
    for(vector< set<pair<int,int> > > :: const_iterator it = listSPRs.begin(); it != listSPRs.end(); ++it)
    {
        for(set<pair<int,int> > :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
        {
            // rank = sum of distance from the two nodes (src/dest) to their LCA
            map<int,map<int,int> > :: iterator it11 = mapNodeDistToAnces.find(it2->first);
            YW_ASSERT_INFO(it11 != mapNodeDistToAnces.end(), "Fail to find abc");
            //map<int,int> :: iterator it12 = it11->second.find(it->first);
            map<int,int> :: iterator it12 = it11->second.find(nodeLCA);
            YW_ASSERT_INFO(it12 != it11->second.end(), "Fail to find abd");
            map<int,map<int,int> > :: iterator it21 = mapNodeDistToAnces.find(it2->second);
            YW_ASSERT_INFO(it21 != mapNodeDistToAnces.end(), "Fail to find abc");
            //map<int,int> :: iterator it22 = it21->second.find(it->first);
            map<int,int> :: iterator it22 = it21->second.find(nodeLCA);
            YW_ASSERT_INFO(it22 != it21->second.end(), "Fail to find abd");
            int rank = it12->second + it22->second;
            //pair<int, pair<int,int> > pp(it->first, *it2);
            pair<int, pair<int,int> > pp(nodeLCA, *it2);
            mapRankedSPRs[rank].insert(pp);
        }
        ++nodeLCA;
    }
    //
    for(map<int, set<pair<int, pair<int,int> > > > :: iterator it1 = mapRankedSPRs.begin(); it1 != mapRankedSPRs.end(); ++it1)
    {
        for( set<pair<int, pair<int,int> > > :: iterator it2 = it1->second.begin(); it2 != it1->second.end(); ++it2 )
        {
            listSPRsOrdered.push_back(*it2);
        }
    }
    
}

double ScistFastSPRLocalSearch :: CalcMaxQForSPR(int site, int noder, int nodeu, int nodew) const
{
//cout << "CalcMaxQForSPR: site:" << site << ", noder:" << noder << ", nodeu:" << nodeu << ", nodew:" << nodew << endl;
    // don't allow SPR to original
    if( mtree.GetParent(nodeu) == mtree.GetParent(nodew) )
    {
        return MAX_NEG_DOUBLE_VAL;
    }
    
    int nodev = mtree.GetParent(nodeu);
    //double prob1 = MAX_NEG_DOUBLE_VAL;
    // get the child on the other side of u
    int nodev1 = mtree.GetSibling(nodeu);
    YW_ASSERT_INFO(mtree.GetParent(nodev1) == nodev, "Wrong child");
    double prob1 = MAX_NEG_DOUBLE_VAL;
    if( mtree.GetParent(nodeu) != noder  )
    {
        // there is some sibling of u not on the SPR loop
        prob1 = this->tblM0[site][nodev1];
    }
    double prob2 = this->tblM0[site][nodeu];
    double prob3 = this->tblM0[site][nodew];
    //map<int,map<int, double> > :: const_iterator it1;
    map<int, double> :: const_iterator it2;
    double prob4 = MAX_NEG_DOUBLE_VAL;
    if( nodev != noder )
    {
        //it1 = this->tblM2[site].find(nodev);
        //YW_ASSERT_INFO(it1 != this->tblM2[site].end(), "Fail112");
        //it2 = it1->second.find(noder);
        //YW_ASSERT_INFO(it2 != it1->second.end(), "Fail112-1");
        it2 = this->tblM2[site][nodev].find(noder);
        YW_ASSERT_INFO(it2 != this->tblM2[site][nodev].end(), "Fail112-1");
        prob4 = it2->second;
    }
    //it1 = this->tblM2[site].find(nodew);
    //YW_ASSERT_INFO(it1 != this->tblM2[site].end(), "Fail112-2");
    //it2 = it1->second.find(noder);
    //YW_ASSERT_INFO(it2 != it1->second.end(), "Fail112-3");
    it2 = this->tblM2[site][nodew].find(noder);
    YW_ASSERT_INFO(it2 != this->tblM2[site][nodew].end(), "Fail112-3");
    double prob5 = it2->second;
    double prob6 = MAX_NEG_DOUBLE_VAL;
    if( noder != mtree.GetRoot() )
    {
        //it1 = this->tblM2[site].find(noder);
        //YW_ASSERT_INFO(it1 != this->tblM2[site].end(), "Fail112-4");
        //it2 = it1->second.find(mtree.GetRoot());
        //YW_ASSERT_INFO(it2 != it1->second.end(), "Fail112-5");
        it2 = this->tblM2[site][noder].find(mtree.GetRoot());
        YW_ASSERT_INFO(it2 != this->tblM2[site][noder].end(), "Fail112-5");
        prob6 = it2->second;
    }
    // get the max of the other side of the root
    double prob7 = MAX_NEG_DOUBLE_VAL;
    if( noder != mtree.GetRoot() )
    {
        int childRootOtherSide = mtree.GetLeftDescendant(mtree.GetRoot());
        //map<int,set<int> > :: const_iterator itt2 = this->mapListAnces.find(noder);
        //YW_ASSERT_INFO(itt2 != this->mapListAnces.end(), "FAIL1114");
        //if( itt2->second.find(childRootOtherSide) != itt2->second.end() )
        if( this->mapListAnces[noder].find(childRootOtherSide) != this->mapListAnces[noder].end() )
        {
            childRootOtherSide = mtree.GetRightDescendant(mtree.GetRoot());
        }
        prob7 = this->tblM0[site][childRootOtherSide];
    }
    double prob8 = MAX_NEG_DOUBLE_VAL;
    if( nodev != noder)
    {
        int nodev1 = mtree.GetParent(nodev);
        if( nodev1 != noder )
        {
            //it1 = this->tblM1[site].find(nodev1);
            //YW_ASSERT_INFO(it1 != this->tblM1[site].end(), "Fail113");
            //it2 = it1->second.find(noder);
            //YW_ASSERT_INFO(it2 != it1->second.end(), "Fail112-6");
            it2 = this->tblM1[site][nodev1].find(noder);
            YW_ASSERT_INFO(it2 != this->tblM1[site][nodev1].end(), "Fail112-6");
            prob8 = it2->second - this->tblQ[site][nodeu];
        }
    }
    double prob9 = MAX_NEG_DOUBLE_VAL;
    if( nodew != noder)
    {
        //it1 = this->tblM1[site].find(nodew);
        //YW_ASSERT_INFO(it1 != this->tblM1[site].end(), "Fail114");
        //it2 = it1->second.find(noder);
        //YW_ASSERT_INFO(it2 != it1->second.end(), "Fail112-7");
        it2 = this->tblM1[site][nodew].find(noder);
        YW_ASSERT_INFO(it2 != this->tblM1[site][nodew].end(), "Fail112-7");
        prob9 = it2->second + this->tblQ[site][nodeu];
    }
    double prob10 = MAX_NEG_DOUBLE_VAL;
    if( noder != mtree.GetRoot() )
    {
        //it1 = this->tblM1[site].find(noder);
        //YW_ASSERT_INFO(it1 != this->tblM1[site].end(), "Fail114");
        //it2 = it1->second.find(mtree.GetRoot());
        //YW_ASSERT_INFO(it2 != it1->second.end(), "Fail114");
        it2 = this->tblM1[site][noder].find( mtree.GetRoot() );
        YW_ASSERT_INFO(it2 != this->tblM1[site][noder].end(), "Fail114");
        prob10 = it2->second;
    }
    // finally allow the root Q value to be included
    double prob11 = this->tblQ[site][mtree.GetRoot()];
//cout << "CalcMaxQForSPR: p1:" << prob1 << ", p2:" << prob2 << ", p3:" << prob3 << ", p4:" << prob4 << ", p5:" << prob5 << ", p6:" << prob6 << ", p7:" << prob7 << ", p8:" << prob8 << ", p9:" << prob9 << ", p10:" << prob10 << endl;
    double res = std::max(prob1, std::max(prob2, std::max(prob3, std::max( prob4, std::max(prob5, std::max(prob6, std::max(prob7, std::max(prob8, std::max( prob9, std::max(prob10,prob11)) ))))))));
    if( res < 0.0 )
    {
        res = 0.0;
    }
    return res;
}

double ScistFastSPRLocalSearch :: CalcMaxQForReroot(int site, int node, int nodeSub) const
{
//cout << "CalcMaxQForReroot: site:" << site << ", node:" << node << ", nodeSub:" << nodeSub << endl;

    // get the child of node that is not ancestral nodeSub (i.e., on the other side)
    int nodeChildOther = mtree.GetLeftDescendant(node);
    if( IsNodeAncestralTo(nodeChildOther, nodeSub) )
    {
        nodeChildOther = mtree.GetRightDescendant(node);
    }
    
    // prob1: max within subtree nodeSub
    double prob1 = this->tblM0[site][nodeSub];
    // prob2: max within subtree nodeOtherChild
    double prob2 = this->tblM0[site][nodeChildOther];
    // prob3: the original Q at node
    double prob3 = this->tblQ[site][node];
    
    map<int, double> :: const_iterator it2;
    // prob4: max of Q among side chains off the path node to nodeSub
    //it2 = this->tblM2[site][nodeSub].find(node);
    //YW_ASSERT_INFO(it2 != this->tblM2[site][nodeSub].end(), "Fail112-1");
    //double prob4 = it2->second;
    // prob5: max along path from node to root
    double prob5 = MAX_NEG_DOUBLE_VAL;
    if( node != mtree.GetRoot() )
    {
        it2 = this->tblM1[site][node].find(mtree.GetRoot());
        YW_ASSERT_INFO(it2 != this->tblM1[site][node].end(), "Fail112-5");
        prob5 = it2->second;;
    }
    // prob6: max along nodes from
    double prob6 = MAX_NEG_DOUBLE_VAL;
    it2 = this->tblM2[site][nodeSub].find(mtree.GetRoot());
    YW_ASSERT_INFO(it2 != this->tblM2[site][nodeSub].end(), "Fail112-5");
    prob6 = it2->second;
    //}
    // prob7: max over the other side of subtree
    double prob7 = MAX_NEG_DOUBLE_VAL;
    if( node != mtree.GetRoot() )
    {
        int childRootOtherSide = mtree.GetLeftDescendant(mtree.GetRoot());
        if( this->mapListAnces[node].find(childRootOtherSide) != this->mapListAnces[node].end() )
        {
            childRootOtherSide = mtree.GetRightDescendant(mtree.GetRoot());
        }
        prob7 = this->tblM0[site][childRootOtherSide];
    }
    double prob8 = MAX_NEG_DOUBLE_VAL;
    int nodev1 = mtree.GetParent(nodeSub);
    if( nodev1 != node )
    {
        it2 = this->tblM4[site][nodeSub].find(node);
        YW_ASSERT_INFO(it2 != this->tblM4[site][nodeSub].end(), "Fail112-6");
        prob8 = it2->second + this->tblQ[site][nodeChildOther];
    }
    
    // finally allow the root Q value to be included
    double prob9 = this->tblQ[site][mtree.GetRoot()];
//cout << "CalcMaxQReroot: p1:" << prob1 << ", p2:" << prob2 << ", p3:" << prob3 << ", p5:" << prob5 << ", p6:" << prob6 << ", p7:" << prob7 << ", p8:" << prob8 << ", p9:" << prob9 << endl;
    double res = std::max(prob1, std::max(prob2, std::max(prob3, std::max(prob5, std::max(prob6, std::max(prob7, std::max(prob8, prob9 )))))));
    if( res < 0.0 )
    {
        res = 0.0;
    }
    return res;
}

// **************************************************************
// Fast rSPR local search to find opt tree

// default search opt parameters
const int DEF_MAX_NUM_ITERS = 10;
//const int DEF_MAX_MULTI_SPRS_MOVES = 0;
const double DEF_THRES_PROB_INC = log(1.00001);

ScistFastSPRLocalSearchLoop :: ScistFastSPRLocalSearchLoop(const ScistGenGenotypeMat &genosInputIn, const string &strTreeInitIn /*const ScistPerfPhyGuideTree &treeGuideIn*/) : genosInput(genosInputIn), strTreeInit(strTreeInitIn), /*treeGuide(treeGuideIn),*/ minProbInc(DEF_THRES_PROB_INC), maxIters(DEF_MAX_NUM_ITERS), numThreads(1), /*maxMultiSPRsMoves(DEF_MAX_MULTI_SPRS_MOVES), */ fHeu(true), heuFracSPR(1.0), thresSPRDrop(100), fVerbose(false)
{
}
double ScistFastSPRLocalSearchLoop :: FindOpt(string &strTreeOpt)
{
// testing: Nov 3, 2023
return FindOptMulti(strTreeOpt);
    // now adjust by the overall prob(allele=0)
    // strTreeOpt: already initialzed with the initial tree
    //double sumLogprobAllele0 = this->genosInput.CalcSumLogProbAllele0All();
//cout << "sum of log prob allele 0 = " << sumLogprobAllele0 << endl;
    
    //
    ScistFastSPRLocalSearch treeSearchCur(this->genosInput, /*this->treeGuide, */ this->strTreeInit, this->numThreads );
    treeSearchCur.SetHeuristicMode( this->fHeu, this->heuFracSPR, this->thresSPRDrop );
    //double probMaxCurr = treeSearchCur.CalcCurrMaxProb();
    double probMaxCurr = treeSearchCur.GetCurrMaxProb();
    //cout << "Initial SPR log-likelihood: " << probMaxCurr << endl;
//cout << "Initial max Q value : " << probMaxCurr << endl;
    
    // keep track for each SPR source, the maximum changed prob it can get
    int numHaps = this->genosInput.GetNumHaps();
    vector<double> mapMaxProbSPRSrc( 2*numHaps ), mapMaxProbSPRDest(2*numHaps);
    for(int i=0; i<2*numHaps; ++i)
    {
        mapMaxProbSPRSrc[i] = MAX_NEG_DOUBLE_VAL;
        mapMaxProbSPRDest[i] = MAX_NEG_DOUBLE_VAL;
    }
    //set<int> setLowPerformerSrc;
    
    //probMaxCurr += sumLogprobAllele0;
    
    MarginalTree mTreeCurr;
    treeSearchCur.GetCurrTree(mTreeCurr);
    
    //double score0 = ScoreTree(mTreeCurr);
    //cout << "(INITIIAL tree: Re-computing log-likelihood: " << score0 << endl;
    
    // now start SPR local search
    //bool fMultiModeEnabled = true;
    int numIters = 0;
    
    set<int> setDropped, setDroppedDest;
    
    while(++numIters <= this->maxIters)
    {
//cout << "**** Current max prob: " << probMaxCurr << "    treeSearchCur: ";
//cout << mTreeCurr.GetNewickNoBrLen() << endl;
        // search for opt
        int nodeSPRSrc, nodeSPRDest, nodeLCA;
        double probMaxStep = treeSearchCur.GetOpt1SPRMove(nodeSPRSrc, nodeSPRDest, nodeLCA, &mapMaxProbSPRSrc, &mapMaxProbSPRDest);
//cout << "Done with 1-SPR neighborhood search\n";
        
        // adjust
        //probMaxStep += sumLogprobAllele0;
        
        if( probMaxStep < probMaxCurr + this->minProbInc)
        {
            //cout << "SPR: cannot improve.\n";
            break;
        }
        
#if 0
        // disallow sites that cannot bring signnature improvement
        cout << "mapMaxProbSPRSrc: probMaxCurr = " << probMaxCurr  << "\n";
        for(int i=0; i< mapMaxProbSPRSrc.size(); ++i)
        {
            cout << i << ", " << mapMaxProbSPRSrc[i] << endl;
        }
#endif

        set<int> setDroppedStep;
        for(unsigned int jjj = 0; jjj<mapMaxProbSPRSrc.size(); ++jjj )
        {
            if( jjj < genosInput.GetNumHaps() && mapMaxProbSPRSrc[jjj] < probMaxCurr + this->minProbInc )
            {
                setDroppedStep.insert(jjj);
            }
        }
        UnionSets(setDropped, setDroppedStep);
        
        // process dest
        for(unsigned int jjj = 0; jjj<mapMaxProbSPRDest.size(); ++jjj )
        {
            // for now, for destination only consider leaves
            if( jjj < genosInput.GetNumHaps() && mapMaxProbSPRDest[jjj] < probMaxCurr + this->minProbInc )
            {
                setDroppedDest.insert(jjj);
            }
        }
#if 0
        // also drop those low performers
        const double FRAC_DROP = 0.5;
        const int THRES_MIN_DROP_LOW = 20;
        if(  setDropped.size() + THRES_MIN_DROP_LOW < genosInput.GetNumHaps() )
        {
            set<int> setLowPerformerSrcNew;
            FindSPRSrcLoserFrom( mapMaxProbSPRSrc, setDropped, FRAC_DROP, setLowPerformerSrcNew );
            set<int> setLowPerformerSrcJoin;
            JoinSets(setLowPerformerSrc, setLowPerformerSrcNew, setLowPerformerSrcJoin);
            cout << "Number of rSPR candidates dropped due to low performance: " << setLowPerformerSrcJoin.size() << endl;
            UnionSets(setDropped, setLowPerformerSrcJoin);
            setLowPerformerSrc = setLowPerformerSrcNew;
        }
#endif
        
        probMaxCurr = probMaxStep;
        // move to the next
        //cout << "Prior to SPR: tree = " << mTreeCurr.GetNewickNoBrLen() << endl;
        //mTreeCurr.Dump();
        //double scorep = ScoreTree(mTreeCurr);
        //cout << "(Before SPR: Re-computing log-likelihood: " << scorep << endl;
        //mTreeCurr.Dump();
        
        mTreeCurr.PerformSPR(nodeSPRSrc, nodeSPRDest);
//cout << "AFTER performing 1 SPR: tree is: " << mTreeCurr.GetNewickNoBrLen() << endl;
//mTreeCurr.Dump();
        
        // temp code
        //double score = ScoreTree(mTreeCurr);
        //cout << "Re-computing log-likelihood: " << score << endl;
        
        treeSearchCur.SetInitTree(mTreeCurr);
        treeSearchCur.SetCurrMaxProb( probMaxCurr );
        
        if( fVerbose )
        {
            cout << "++ 1-rSPR local search: likelihood improved to " << probMaxCurr << endl;
        }
        
        if( setDropped.size() > 0 )
        {
            //cout << "Drop the following edges from rSPR search: ";
            //DumpIntSet(setDropped );
            for(set<int> :: iterator itta = setDropped.begin(); itta != setDropped.end(); ++itta )
            {
                treeSearchCur.SetEdgeCandidate(*itta, false);
            }
        }
        if( setDroppedDest.size() > 0 )
        {
            //cout << "Drop the following edges from rSPR search: ";
            //DumpIntSet(setDropped );
            for(set<int> :: iterator itta = setDroppedDest.begin(); itta != setDroppedDest.end(); ++itta )
            {
                treeSearchCur.SetEdgeCandidateDest(*itta, false);
            }
        }
    }
    //cout << "Total number of rSPR local search steps: " << numIters << endl;
    //cout << "**** Maximum log-likelihood: " << probMaxCurr << endl;
    //cout << "Constructed single cell phylogeny: " << mTreeCurr.GetNewickNoBrLen() << endl;
    
    strTreeOpt = mTreeCurr.GetNewickNoBrLen();
    
    // now valid to make sure it is indeed the same prob
    //ScistPerfPhyGuideTree treeGuidThis;
    //treeGuidThis.InitDecAll(strTreeOpt);
    //ScistFastSPRLocalSearch treeSearchCur2(this->genosInput, treeGuidThis );
    //double probMaxCurr2 = treeSearchCur.CalcCurrMaxProb();
    //probMaxCurr2 += sumLogprobAllele0;
    //cout << "Recomputed log-likelihood: " << probMaxCurr2 << endl;
    
    return probMaxCurr;
}

double ScistFastSPRLocalSearchLoop :: FindOptMulti(string &strTreeOpt)
{
    // Perform multiple rSPR based on a single SPR search
    // strTreeOpt: already initialzed with the initial tree
    //double sumLogprobAllele0 = this->genosInput.CalcSumLogProbAllele0All();
//cout << "sum of log prob allele 0 = " << sumLogprobAllele0 << endl;
    
    //
    ScistFastSPRLocalSearch treeSearchCur(this->genosInput,this->strTreeInit, this->numThreads );
    treeSearchCur.SetHeuristicMode( this->fHeu, this->heuFracSPR, this->thresSPRDrop );
    //double probMaxCurr = treeSearchCur.CalcCurrMaxProb();
    double probMaxCurr = treeSearchCur.GetCurrMaxProb();
    //cout << "Initial SPR log-likelihood: " << probMaxCurr << endl;
//cout << "Initial max Q value : " << probMaxCurr << endl;
    
    // keep track for each SPR source, the maximum changed prob it can get
    int numHaps = this->genosInput.GetNumHaps();
    vector<double> mapMaxProbSPRSrc( 2*numHaps ), mapMaxProbSPRDest(2*numHaps);
    for(int i=0; i<2*numHaps; ++i)
    {
        mapMaxProbSPRSrc[i] = MAX_NEG_DOUBLE_VAL;
        mapMaxProbSPRDest[i] = MAX_NEG_DOUBLE_VAL;
    }
    
    MarginalTree mTreeCurr;
    treeSearchCur.GetCurrTree(mTreeCurr);
    
    //double score0 = ScoreTree(mTreeCurr);
    //cout << "(INITIIAL tree: Re-computing log-likelihood: " << score0 << endl;
    
    // now start SPR local search
    int numIters = 0;
    
    set<int> setDropped, setDroppedDest;
    
    while(++numIters <= this->maxIters)
    {
        if( fVerbose )
        {
        //    cout << "++FindOptMulti: iteration " << numIters << endl;
        }
        // find out all the clades of current ree
        vector<set<int> > listDescLaves;
        mTreeCurr.ConsDecedentLeavesInfo( listDescLaves );
        
//cout << "**** Current max prob: " << probMaxCurr << "    treeSearchCur: ";
//cout << mTreeCurr.GetNewickNoBrLen() << endl;
        // search for opt
        int nodeSPRSrc, nodeSPRDest, nodeLCA;
        std::map<std::pair<int,int>,double> mapSPRProbs;
        double probMaxStep = treeSearchCur.GetOpt1SPRMove(nodeSPRSrc, nodeSPRDest, nodeLCA, &mapMaxProbSPRSrc, &mapMaxProbSPRDest, &mapSPRProbs);
//cout << "Done with 1-SPR neighborhood search\n";
        
        // adjust
        //probMaxStep += sumLogprobAllele0;
        
        if( probMaxStep < probMaxCurr + this->minProbInc)
        {
            //cout << "SPR: cannot improve.\n";
            break;
        }
        
#if 0
        // disallow sites that cannot bring signnature improvement
        cout << "mapMaxProbSPRSrc: probMaxCurr = " << probMaxCurr  << "\n";
        for(int i=0; i< mapMaxProbSPRSrc.size(); ++i)
        {
            cout << i << ", " << mapMaxProbSPRSrc[i] << endl;
        }
#endif

        set<int> setDroppedStep;
        for(unsigned int jjj = 0; jjj<mapMaxProbSPRSrc.size(); ++jjj )
        {
            if( jjj < genosInput.GetNumHaps() && mapMaxProbSPRSrc[jjj] < probMaxCurr + this->minProbInc )
            {
                setDroppedStep.insert(jjj);
            }
        }
        UnionSets(setDropped, setDroppedStep);
        
        // process dest
        for(unsigned int jjj = 0; jjj<mapMaxProbSPRDest.size(); ++jjj )
        {
            // for now, for destination only consider leaves
            if( jjj < genosInput.GetNumHaps() && mapMaxProbSPRDest[jjj] < probMaxCurr + this->minProbInc )
            {
                setDroppedDest.insert(jjj);
            }
        }
        
        double probMaxCurrPre = probMaxCurr;
        probMaxCurr = probMaxStep;
        // move to the next
        //cout << "Prior to SPR: tree = " << mTreeCurr.GetNewickNoBrLen() << endl;
        //mTreeCurr.Dump();
        //double scorep = ScoreTree(mTreeCurr);
        //cout << "(Before SPR: Re-computing log-likelihood: " << scorep << endl;
        //mTreeCurr.Dump();
        
        
        mTreeCurr.PerformSPR(nodeSPRSrc, nodeSPRDest);
//cout << "AFTER performing 1 SPR: tree is: " << mTreeCurr.GetNewickNoBrLen() << endl;
//mTreeCurr.Dump();
        treeSearchCur.SetInitTree(mTreeCurr);
        treeSearchCur.SetCurrMaxProb( probMaxCurr );
        
        //set< set<int> > setCladesInSPRs;
        //setCladesInSPRs.insert( listDescLaves[nodeSPRSrc] );
        //setCladesInSPRs.insert( listDescLaves[nodeSPRDest] );
        map<set<int>, int> mapSTToLeaves;
        mTreeCurr.ConsDecedentLeavesInfo2(mapSTToLeaves);
        
        // now perform all possible SPR moves that is good
        int numExtraSPR = 0;
        map<double, set<pair<int,int> > > mapSPRProbs2;
        for(map<pair<int,int>, double> :: iterator it22 = mapSPRProbs.begin(); it22 != mapSPRProbs.end(); ++it22)
        {
            mapSPRProbs2[it22->second].insert(it22->first);
        }
//cout << "Current tree: " << mTreeCurr.GetNewickSorted(false) << endl;
        // now work the way back
        for( map<double, set<pair<int,int> > > :: reverse_iterator it22 = mapSPRProbs2.rbegin(); it22 != mapSPRProbs2.rend(); ++it22 )
        {
            if( it22->first < probMaxCurrPre )
            {
                break;
            }
            
            for(set<pair<int,int> > :: iterator it23 = it22->second.begin(); it23 != it22->second.end(); ++it23)
            {
                int nodeSrcStep = it23->first, nodeDestStep = it23->second;
                // get their subtrees
                set<int> ssSrc = listDescLaves[nodeSrcStep];
                set<int> ssDest = listDescLaves[nodeDestStep];
                // find the STs for these in the current tree
                map<set<int>, int> :: iterator itt4 = mapSTToLeaves.find(ssSrc);
                if( itt4 == mapSTToLeaves.end() )
                {
                    continue;
                }
                map<set<int>, int> :: iterator itt5 = mapSTToLeaves.find(ssDest);
                if( itt5 == mapSTToLeaves.end() )
                {
                    continue;
                }
                int nodeSrc2 = itt4->second, nodeDest2 = itt5->second;
                if( mTreeCurr.GetSibling(nodeSrc2) == nodeDest2 )
                {
                    continue;
                }
//cout << "Evaluating source: " << nodeSrc2 << ", dest: " << nodeDest2 << ", source subtree: ";
//DumpIntSet(ssSrc);
//cout << "   dest subtree: ";
//DumpIntSet(ssDest);
                // now try to perform the rSPR (on a copy of current tree)
                MarginalTree mTreeCurrCopy = mTreeCurr;
                mTreeCurrCopy.PerformSPR(nodeSrc2, nodeDest2);
                double score2 = ScoreTree(mTreeCurrCopy);
                if( score2 > probMaxCurr )
                {
                    // take it
                    if( fVerbose )
                    {
                        //cout << "----- Taking one extra SPR move: src subtree: likelihood improved to: " << score2 << endl;
                    }
                    ++numExtraSPR;
                    probMaxCurr = score2;
                    mTreeCurr.PerformSPR(nodeSrc2, nodeDest2);
                    treeSearchCur.SetInitTree(mTreeCurr);
                    treeSearchCur.SetCurrMaxProb( probMaxCurr );
                    mTreeCurr.ConsDecedentLeavesInfo2(mapSTToLeaves);
#if 0
                    double scoreRecalc = ScoreTree(mTreeCurr);
                    YW_ASSERT_INFO( std::fabs(scoreRecalc-probMaxCurr) < 0.01, "Wrong in additional SPRs" );
                    //cout << "Re-computing log-likelihood: " << score << endl;
#endif
                    
//cout << "After extra SPR move: tree is: " << mTreeCurr.GetNewickSorted(false) << endl;
                }
            }
        }
        
        if( fVerbose && numExtraSPR > 0 )
        {
            cout << "Number of extra SPR moves taken: " << numExtraSPR << endl;
        }
        
        // temp code
        //double score = ScoreTree(mTreeCurr);
        //cout << "Re-computing log-likelihood: " << score << endl;
        
        if( fVerbose )
        {
            cout << "++ 1-rSPR local search: likelihood improved to " << probMaxCurr << endl;
        }
        
        if( setDropped.size() > 0 )
        {
            //cout << "Drop the following edges from rSPR search: ";
            //DumpIntSet(setDropped );
            for(set<int> :: iterator itta = setDropped.begin(); itta != setDropped.end(); ++itta )
            {
                treeSearchCur.SetEdgeCandidate(*itta, false);
            }
        }
        if( setDroppedDest.size() > 0 )
        {
            //cout << "Drop the following edges from rSPR search: ";
            //DumpIntSet(setDropped );
            for(set<int> :: iterator itta = setDroppedDest.begin(); itta != setDroppedDest.end(); ++itta )
            {
                treeSearchCur.SetEdgeCandidateDest(*itta, false);
            }
        }
    }
    //cout << "Total number of rSPR local search steps: " << numIters << endl;
    //cout << "**** Maximum log-likelihood: " << probMaxCurr << endl;
    //cout << "Constructed single cell phylogeny: " << mTreeCurr.GetNewickNoBrLen() << endl;
    
    strTreeOpt = mTreeCurr.GetNewickNoBrLen();
    
    // now valid to make sure it is indeed the same prob
    //ScistPerfPhyGuideTree treeGuidThis;
    //treeGuidThis.InitDecAll(strTreeOpt);
    //ScistFastSPRLocalSearch treeSearchCur2(this->genosInput, treeGuidThis );
    //double probMaxCurr2 = treeSearchCur.CalcCurrMaxProb();
    //probMaxCurr2 += sumLogprobAllele0;
    //cout << "Recomputed log-likelihood: " << probMaxCurr2 << endl;
    
    return probMaxCurr;
}


void ScistFastSPRLocalSearchLoop :: FindSPRSrcLoserFrom( const std::map<int, double> &mapSrcScore, const std::set<int> &setAvoided, double frac, std::set<int> &setSrcLosers ) const
{
    // find the bottom frac (say 0.5) of spr candidates that are not faring well
    setSrcLosers.clear();
    vector<pair<double, int> > listPairs;
    for( std::map<int, double> :: const_iterator it = mapSrcScore.begin(); it != mapSrcScore.end(); ++it )
    {
        if( setAvoided.find(it->first) == setAvoided.end() )
        {
            listPairs.push_back(std::make_pair( it->second, it->first ));
        }
    }
    std::sort( listPairs.begin(), listPairs.end() );
    // put the bottom range
    int posLoser = (int)listPairs.size() * (1.0-frac);
    for(int i=0; i<posLoser; ++i)
    {
        setSrcLosers.insert( listPairs[i].second );
    }
}

double ScistFastSPRLocalSearchLoop :: ScoreTree(MarginalTree &mtree)
{
//cout << "Score tree: " << treeToScore.GetNewick() << endl;
    set<pair<ScistPerfPhyCluster,ScistPerfPhyCluster> > setClusDone;
    //map<pair<ScistPerfPhyCluster,ScistPerfPhyCluster>, pair<ScistPerfPhyCluster,ScistPerfPhyCluster> > mapChangedClus;
    double res = 0.0;;
    ScistGenGenotypeMat &genosInputUse = const_cast<ScistGenGenotypeMat &>(this->genosInput);
    ScistPerfPhyProbOnTree probTree( genosInputUse, mtree );
    
    // YW: do we really need the map as above? TBD
    for(int site=0; site<genosInput.GetNumSites(); ++site)
    {
//cout << "ScoreTree: site " << site << endl;
//cout << "Heterozygote clus: ";
//listClusMutsInputHetero[site].Dump();
//cout << "Homozygous clus: ";
//listClusMutsInputHomo[site].Dump();
        pair<ScistPerfPhyCluster,ScistPerfPhyCluster> clusChanged;
        double loglikeliSite = probTree.CalcProbMaxForSite( site, clusChanged.first, clusChanged.second );
        //mapChangedClus[ pp0 ] = clusChanged;
        //listChangedCluster.push_back(clusChanged);
        res += loglikeliSite;
        //setClusDone.insert( pp0 );
//cout << "site: " << site << ", loglikesite: " << loglikeliSite << endl;
//cout << "site prob: " << loglikeliSite << ": clusChanged: ";
//clusChanged.first.Dump();
//cout << "  and ";
//clusChanged.second.Dump();
    }
    return res;
}

// **************************************************************
// Fast NNI local search

ScistFastNNILocalSearch :: ScistFastNNILocalSearch(const ScistGenGenotypeMat &genosInputIn, const string &treeInitIn, int nt) : genosInput(genosInputIn), numThreads(nt)
{
//cout << "**ScistFastNNILocalSearch:Initial tree: " << strTree << endl;
    ReadinMarginalTreesNewickWLenString(treeInitIn, GetNumCells(), mtree);
    mtree.RearrangeParIncOrder();
    mtree.BuildDescendantInfo();
//cout << "Marginal tree: ";
//mtree.Dump();
    
    Init();
}


void ScistFastNNILocalSearch :: Init()
{
    if( this->numThreads > 1)
    {
        InitMT();
        return;
    }
//cout << "ScistFastNNILocalSearch: Init\n";
    // store values of Q table
    this->tblQ.clear();
    this->tblQ.resize( GetNumSites() );
    this->tblM0.resize(GetNumSites() );
    //this->tblQMax.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblQ[s].resize( mtree.GetTotNodesNum() );
        this->tblM0[s].resize( mtree.GetTotNodesNum() );
    }
    //
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "InitQTbl: site:" << site << endl;
        // do a bottom up
        vector<double> listNodeSplitProb;
        // init to be bad
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            listNodeSplitProb.push_back( -1.0*HAP_MAX_INT );
        }
        
    //cout << "CalcProbMaxForSiteHap: mtree: " << mtree.GetNewickSorted(false) << endl;
    //mtree.Dump();
        //this->tblQMax[site] = MAX_NEG_DOUBLE_VAL;
        
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
//cout << "node " << node << endl;
            double logpStep = 0.0;
            if( mtree.IsLeaf(node) )
            {
//cout << "Leaf label: " << mtree.GetLabel(node) << endl;
                // a single leaf in the split
                int lvlbl = mtree.GetLabel(node)-1;
                //cout << "Leaf: " << lvlbl << endl;
                double p0 = this->genosInput.GetGenotypeProbAllele0At(lvlbl, site);
                if( p0 < YW_VERY_SMALL_FRACTION)
                {
                    p0 = YW_VERY_SMALL_FRACTION;
                }
                else if( p0 > 1.0-YW_VERY_SMALL_FRACTION)
                {
                    p0 = 1.0-YW_VERY_SMALL_FRACTION;
                }
                logpStep = log((1-p0)/p0);
                
                this->tblM0[site][node] = logpStep;
//cout << "Set leaf " << node << " log prob to: " << logpStep << ", p0=" << p0 << endl;
            }
            else
            {
                // get the two children and add them up
                int childLeft = mtree.GetLeftDescendant(node);
                int childRight = mtree.GetRightDescendant(node);
    //cout << "node: " << node << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
                //cout << "childLeft: " << childLeft << ", right: " << childRight << endl;
                
                YW_ASSERT_INFO( listNodeSplitProb[childLeft] > -1.0*HAP_MAX_INT, "Bad left-c" );
                YW_ASSERT_INFO( listNodeSplitProb[childRight] > -1.0*HAP_MAX_INT, "Bad right1-c" );
                logpStep = listNodeSplitProb[childLeft] + listNodeSplitProb[childRight];
                
                this->tblM0[site][node] = logpStep;
                this->tblM0[site][node] = std::max(this->tblM0[site][node], this->tblM0[site][childLeft] );
                this->tblM0[site][node] = std::max(this->tblM0[site][node], this->tblM0[site][childRight] );
//cout << "node: " << node << ", prob: " << logpStep << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
            }
//cout << "log prob: " << logpStep << " for node: " << node << endl;
            listNodeSplitProb[node] = logpStep;
            
            //if( logpStep > this->tblQMax[site] )
            //{
            //    this->tblQMax[site] = logpStep;
            //}
        }
        
        // save the probs
        this->tblQ[site] = listNodeSplitProb;
    }
    
    // now init M1 table.
    this->tblM1.resize(GetNumSites());
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "Init tblM1: " << site << endl;
        // start from root down to leaf
        // for root, set to the smallest log-prob
        this->tblM1[site].resize(GetNumNodesInTree());
        tblM1[site][mtree.GetRoot()] = MAX_NEG_DOUBLE_VAL;
        for(int node=GetNumNodesInTree()-2; node >=0; --node )
        {
            int nodeSib = mtree.GetSibling(node);
            int nodePar = mtree.GetParent(node);
            YW_ASSERT_INFO(nodeSib >= 0, "Fail to find sibling");
            YW_ASSERT_INFO(nodePar >= 0, "Fail to find parent");
            tblM1[site][node] = std::max( this->tblQ[site][nodePar], tblM0[site][nodeSib] );
            tblM1[site][node] = std::max( this->tblM1[site][node], tblM1[site][nodePar]  );
        }
    }
#if 0
    cout << "****** TblQ: \n";
    for(int site=0; site<GetNumSites(); ++site)
    {
        DumpDoubleVec(this->tblQ[site]);
    }
    cout << "****** TblM0: \n";
    for(int site=0; site<GetNumSites(); ++site)
    {
        DumpDoubleVec(this->tblM0[site]);
    }
    cout << "****** TblM1: \n";
    for(int site=0; site<GetNumSites(); ++site)
    {
        DumpDoubleVec(this->tblM1[site]);
    }
#endif
}

static void UtilsInitMTProc(MarginalTree *ptree, const ScistGenGenotypeMat *pgenosInput, int siteStart, int siteEnd, int numSites, vector<std::vector<double> > *pTblQ, vector<std::vector<double> > *pTblM0, vector<std::vector<double> > *pTblM1 )
{
    //
    for(int site=siteStart; site<=siteEnd; ++site)
    {
//cout << "InitQTbl: site:" << site << endl;
        // do a bottom up
        vector<double> listNodeSplitProb;
        // init to be bad
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            listNodeSplitProb.push_back( -1.0*HAP_MAX_INT );
        }
        
    //cout << "CalcProbMaxForSiteHap: mtree: " << mtree.GetNewickSorted(false) << endl;
    //mtree.Dump();
        //this->tblQMax[site] = MAX_NEG_DOUBLE_VAL;
        
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
//cout << "node " << node << endl;
            double logpStep = 0.0;
            if( ptree->IsLeaf(node) )
            {
//cout << "Leaf label: " << mtree.GetLabel(node) << endl;
                // a single leaf in the split
                int lvlbl = ptree->GetLabel(node)-1;
                //cout << "Leaf: " << lvlbl << endl;
                double p0 = pgenosInput->GetGenotypeProbAllele0At(lvlbl, site);
                if( p0 < YW_VERY_SMALL_FRACTION)
                {
                    p0 = YW_VERY_SMALL_FRACTION;
                }
                else if( p0 > 1.0-YW_VERY_SMALL_FRACTION)
                {
                    p0 = 1.0-YW_VERY_SMALL_FRACTION;
                }
                logpStep = log((1-p0)/p0);
                
                (*pTblM0)[site][node] = logpStep;
//cout << "Set leaf " << node << " log prob to: " << logpStep << ", p0=" << p0 << endl;
            }
            else
            {
                // get the two children and add them up
                int childLeft = ptree->GetLeftDescendant(node);
                int childRight = ptree->GetRightDescendant(node);
    //cout << "node: " << node << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
                //cout << "childLeft: " << childLeft << ", right: " << childRight << endl;
                
                YW_ASSERT_INFO( listNodeSplitProb[childLeft] > -1.0*HAP_MAX_INT, "Bad left-d" );
                YW_ASSERT_INFO( listNodeSplitProb[childRight] > -1.0*HAP_MAX_INT, "Bad right1-d" );
                logpStep = listNodeSplitProb[childLeft] + listNodeSplitProb[childRight];
                
                (*pTblM0)[site][node] = logpStep;
                (*pTblM0)[site][node] = std::max( (*pTblM0)[site][node], (*pTblM0)[site][childLeft] );
                (*pTblM0)[site][node] = std::max((*pTblM0)[site][node], (*pTblM0)[site][childRight] );
//cout << "node: " << node << ", prob: " << logpStep << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
            }
//cout << "log prob: " << logpStep << " for node: " << node << endl;
            listNodeSplitProb[node] = logpStep;
            
            //if( logpStep > this->tblQMax[site] )
            //{
            //    this->tblQMax[site] = logpStep;
            //}
        }
        
        // save the probs
        (*pTblQ)[site] = listNodeSplitProb;
    }
    
    // now init M1 table.
    for(int site=siteStart; site<=siteEnd; ++site)
    {
//cout << "Init tblM1: " << site << endl;
        // start from root down to leaf
        // for root, set to the smallest log-prob
        (*pTblM1)[site][ptree->GetRoot()] = MAX_NEG_DOUBLE_VAL;
        for(int node=ptree->GetTotNodesNum()-2; node >=0; --node )
        {
            int nodeSib = ptree->GetSibling(node);
            int nodePar = ptree->GetParent(node);
            YW_ASSERT_INFO(nodeSib >= 0, "Fail to find sibling");
            YW_ASSERT_INFO(nodePar >= 0, "Fail to find parent");
            (*pTblM1)[site][node] = std::max( (*pTblQ)[site][nodePar], (*pTblM0)[site][nodeSib] );
            (*pTblM1)[site][node] = std::max( (*pTblM1)[site][node], (*pTblM1)[site][nodePar]  );
        }
    }
}

void ScistFastNNILocalSearch :: InitMT()
{
//cout << "ScistFastNNILocalSearch: Init\n";
    // store values of Q table
    this->tblQ.clear();
    this->tblQ.resize( GetNumSites() );
    this->tblM0.resize(GetNumSites() );
    this->tblM1.resize(GetNumSites());
    //this->tblQMax.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblQ[s].resize( mtree.GetTotNodesNum() );
        this->tblM0[s].resize( mtree.GetTotNodesNum() );
        this->tblM1[s].resize( mtree.GetTotNodesNum() );
    }
    int numThreadsUse = this->numThreads;
    if( numThreadsUse > GetNumSites() )
    {
        numThreadsUse = GetNumSites();
    }
    int blkSize = GetNumSites()/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= GetNumSites()  || t == numThreadsUse-1)
        {
            blkEnd = GetNumSites()-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitMTProc, &mtree, &genosInput, blkStart, blkEnd, GetNumSites(), &tblQ, &tblM0, &tblM1);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();

#if 0
    cout << "****** TblQ: \n";
    for(int site=0; site<GetNumSites(); ++site)
    {
        DumpDoubleVec(this->tblQ[site]);
    }
    cout << "****** TblM0: \n";
    for(int site=0; site<GetNumSites(); ++site)
    {
        DumpDoubleVec(this->tblM0[site]);
    }
    cout << "****** TblM1: \n";
    for(int site=0; site<GetNumSites(); ++site)
    {
        DumpDoubleVec(this->tblM1[site]);
    }
#endif
}


double ScistFastNNILocalSearch :: CalcCurrMaxProb(std::string &strNNIBestTree) const
{
    //if(this->numThreads > 1 && GetNumNodesInTree() > this->numThreads )
    if(this->numThreads > 1 )
    {
        return CalcCurrMaxProbMT(strNNIBestTree);
    }
    
    //
    double logProbMaxNNI = MAX_NEG_DOUBLE_VAL;
    int nodeNNI = -1, nodeNNIDest = -1;;
    for(int node=0; node<GetNumNodesInTree(); ++node)
    {
        if( node == mtree.GetRoot() )
        {
            continue;
        }
        int nodePar = mtree.GetParent(node);
        if( nodePar == mtree.GetRoot() )
        {
            continue;
        }
        int nodeParSib =mtree.GetSibling(nodePar);
        int nodeSib = mtree.GetSibling(node);
        YW_ASSERT_INFO(nodeParSib >= 0, "Fail to find sibling of parent node");
        YW_ASSERT_INFO(nodeSib >=0, "Fail to find sibling of node");
        //
//cout << "--NNI: node:" << node << ", sibliing: " << nodeParSib << endl;
        double logProbNewNode = 0.0;
        for(int site=0; site<GetNumSites(); ++site)
        {
            double probMaxNode = this->tblQ[site][node] + this->tblQ[site][nodeParSib];
            double probSub1 = this->tblM0[site][node];
            double probSub = std::max(probSub1, this->tblM0[site][nodeSib]);
            double maxProbStep = std::max(probMaxNode, probSub);
            //double maxProbStep2 = std::max(maxProbStep, this->tblM0[site][nodeParSib]);
            double probPar = this->tblM1[site][nodePar];
            maxProbStep = std::max(maxProbStep, probPar);
            
            // finally if the result is not better than all-0, use all-0. That is, if max is smaller than 0, use 0
            if( 0.0 > maxProbStep )
            {
//cout << "**** TAKING all-0 option at site: " << site << endl;
                maxProbStep = 0.0;
            }
            
            logProbNewNode += maxProbStep;
//cout << "max prob at site: " << site << ": " << maxProbStep << "  probMaxNode:" << probMaxNode << ", probSub:" << probSub << ", probPar:" << probPar << ", max BEFORE NNI: " << this->tblM0[site][mtree.GetRoot()] << endl;
        }
        if( logProbMaxNNI < logProbNewNode )
        {
//cout << "Higher NNI: nodeNNI: " << node << ", NNI dest:" << nodeParSib << ", logProbNewNode: " << logProbNewNode << endl;
            logProbMaxNNI = logProbNewNode;
            nodeNNI = node;
            nodeNNIDest = nodeParSib;
        }
    }
    
#if 0
    // Oct 20: added another way of NNI: node to be sibling of parent of parent of node
    for(int node=0; node<GetNumNodesInTree(); ++node)
    {
        if( node == mtree.GetRoot() )
        {
            continue;
        }
        int nodePar = mtree.GetParent(node);
        int nodeSib = mtree.GetSibling(node);
        YW_ASSERT_INFO(nodeSib >=0, "Fail to find sibling of node");
        if( mtree.IsLeaf(nodeSib) )
        {
            continue;
        }
        int nodeSibChildLeft = mtree.GetLeftDescendant(nodeSib);
        int nodeSibChildRight = mtree.GetRightDescendant(nodeSib);
        YW_ASSERT_INFO(nodeSibChildLeft >=0 && nodeSibChildRight>=0, "Fail to find children of sibling node");
        //
//cout << "--NNI: node:" << node << ", sibliing: " << nodeParSib << endl;
        double logProbNewNodeLeft = 0.0, logProbNewNodeRight = 0.0;
        for(int site=0; site<GetNumSites(); ++site)
        {
            double probMaxNodeLeft = this->tblQ[site][node] + this->tblQ[site][nodeSibChildLeft];
            double probMaxNodeRight = this->tblQ[site][node] + this->tblQ[site][nodeSibChildRight];
            double probSub1 = this->tblM0[site][node];
            double probSub2 = std::max(probSub1, this->tblM0[site][nodeSibChildLeft]);
            double probSub = std::max(probSub2, this->tblM0[site][nodeSibChildRight]);
            double maxProbStepLeft = std::max(probMaxNodeLeft, probSub);
            double maxProbStepRight = std::max(probMaxNodeRight, probSub);
            double probPar = this->tblM1[site][nodePar];
            maxProbStepLeft = std::max(maxProbStepLeft, probPar);
            maxProbStepRight = std::max(maxProbStepRight, probPar);
            
            // finally if the result is not better than all-0, use all-0. That is, if max is smaller than 0, use 0
            if( 0.0 > maxProbStepLeft )
            {
//cout << "**** TAKING all-0 option at site: " << site << endl;
                maxProbStepLeft = 0.0;
            }
            if( 0.0 > maxProbStepRight )
            {
//cout << "**** TAKING all-0 option at site: " << site << endl;
                maxProbStepRight = 0.0;
            }
            
            logProbNewNodeLeft += maxProbStepLeft;
            logProbNewNodeRight += maxProbStepRight;
//cout << "max prob at site: " << site << ": " << maxProbStep << "  probMaxNode:" << probMaxNode << ", probSub:" << probSub << ", probPar:" << probPar << ", max BEFORE NNI: " << this->tblM0[site][mtree.GetRoot()] << endl;
        }
        if( logProbMaxNNI < logProbNewNodeLeft )
        {
//cout << "Higher NNI: nodeNNI: " << node << ", NNI dest:" << nodeParSib << ", logProbNewNode: " << logProbNewNode << endl;
            logProbMaxNNI = logProbNewNodeLeft;
            nodeNNI = node;
            nodeNNIDest = nodeSibChildLeft;
        }
        if( logProbMaxNNI < logProbNewNodeRight )
        {
//cout << "Higher NNI: nodeNNI: " << node << ", NNI dest:" << nodeParSib << ", logProbNewNode: " << logProbNewNode << endl;
            logProbMaxNNI = logProbNewNodeRight;
            nodeNNI = node;
            nodeNNIDest = nodeSibChildRight;
        }
    }
#endif
    
    // construct current tree
    YW_ASSERT_INFO(nodeNNI >= 0 && nodeNNIDest >= 0, "Fail to find NNI" );
    MarginalTree mTreeCurr = this->mtree;
    mTreeCurr.PerformSPR(nodeNNI, nodeNNIDest);
    strNNIBestTree = mTreeCurr.GetNewickNoBrLen();
    
    // add on the overall prob of zero for all genotypes
    double prob0All = this->genosInput.CalcSumLogProbAllele0All();
//cout << "ProbZeroAll: " << prob0All << endl;
    double logProbMaxNNIRes = logProbMaxNNI + prob0All;
//cout << "logProbMaxNNIRes: " << logProbMaxNNIRes << ", nodeNNI:" << nodeNNI << ", nodeNNIDest:" << nodeNNIDest << endl;
    
// test code
//double probM0Orig = 0.0;
//for(int site=0; site<GetNumSites(); ++site)
//{
//probM0Orig += this->tblM0[site][mtree.GetRoot()];
//}
//probM0Orig += prob0All;
//cout << "CHECKING: log-likelihood computed by M0 table on original tree: " << probM0Orig << endl;
    
    return logProbMaxNNIRes;
}

static void UtilsFindBestNNIMove( const MarginalTree *ptree, int tindex, int nodeStart, int nodeEnd, int numSites, const vector<std::vector<double> > *pTblQ, const vector<std::vector<double> > *pTblM0, const vector<std::vector<double> > *pTblM1, vector<double> *pListProb, vector<int> *pListNodeNNISrc, vector<int> *pListNodeNNIDest)
{
    double logProbMaxNNI = MAX_NEG_DOUBLE_VAL;
    int nodeNNISrc = -1;
    int nodeNNIDest = -1;
    for(int node=nodeStart; node<=nodeEnd; ++node)
    {
        if( node == ptree->GetRoot() )
        {
            continue;
        }
        int nodePar = ptree->GetParent(node);
        if( nodePar == ptree->GetRoot() )
        {
            continue;
        }
        int nodeParSib =ptree->GetSibling(nodePar);
        int nodeSib = ptree->GetSibling(node);
        YW_ASSERT_INFO(nodeParSib >= 0, "Fail to find sibling of parent node");
        YW_ASSERT_INFO(nodeSib >=0, "Fail to find sibling of node");
        //
//cout << "--NNI: node:" << node << ", sibliing: " << nodeParSib << endl;
        double logProbNewNode = 0.0;
        for(int site=0; site<numSites; ++site)
        {
            double probMaxNode = (*pTblQ)[site][node] + (*pTblQ)[site][nodeParSib];
            double probSub1 = (*pTblM0)[site][node];
            double probSub = std::max(probSub1, (*pTblM0)[site][nodeSib]);
            double maxProbStep = std::max(probMaxNode, probSub);
            double probPar = (*pTblM1)[site][nodePar];
            maxProbStep = std::max(maxProbStep, probPar);
            
            // finally if the result is not better than all-0, use all-0. That is, if max is smaller than 0, use 0
            if( 0.0 > maxProbStep )
            {
//cout << "**** TAKING all-0 option at site: " << site << endl;
                maxProbStep = 0.0;
            }
            
            logProbNewNode += maxProbStep;
//cout << "max prob at site: " << site << ": " << maxProbStep << "  probMaxNode:" << probMaxNode << ", probSub:" << probSub << ", probPar:" << probPar << ", max BEFORE NNI: " << this->tblM0[site][mtree.GetRoot()] << endl;
        }
        if( logProbMaxNNI < logProbNewNode )
        {
//cout << "Higher NNI: nodeNNI: " << node << ", NNI dest:" << nodeParSib << ", logProbNewNode: " << logProbNewNode << endl;
            logProbMaxNNI = logProbNewNode;
            nodeNNISrc = node;
            nodeNNIDest = nodeParSib;
        }
    }
    
    (*pListProb)[tindex] = logProbMaxNNI;
    (*pListNodeNNISrc)[tindex] = nodeNNISrc;
    (*pListNodeNNIDest)[tindex] = nodeNNIDest;
}

double ScistFastNNILocalSearch :: CalcCurrMaxProbMT(std::string &strNNIBestTree) const
{
    // split nodes into buckets, each for a thread
    int numThreadsUse = this->numThreads;
    if( GetNumNodesInTree() < numThreadsUse )
    {
        numThreadsUse = GetNumNodesInTree();
    }
    vector<int> listNNISrcs(numThreadsUse), listNNIDests(numThreadsUse);
    vector<double> listNNIProbs(numThreadsUse);
    int blkSize = GetNumNodesInTree()/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= GetNumNodesInTree()  || t == numThreadsUse-1)
        {
            blkEnd = GetNumNodesInTree()-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsFindBestNNIMove, &mtree, t, blkStart, blkEnd, GetNumSites(), &tblQ, &tblM0, &tblM1, &listNNIProbs, &listNNISrcs, &listNNIDests );
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
    
    // find the best NNI move
    double logProbMaxNNI = MAX_NEG_DOUBLE_VAL;
    int nodeNNI = -1;
    int nodeNNIDest = -1;
    for(unsigned int i=0; i<listNNIProbs.size(); ++i)
    {
        if( listNNIProbs[i] > logProbMaxNNI + DEF_THRES_PROB_INC )
        {
            logProbMaxNNI = listNNIProbs[i];
            nodeNNI = listNNISrcs[i];
            nodeNNIDest = listNNIDests[i];
        }
    }
    
    // construct current tree
    YW_ASSERT_INFO(nodeNNI >= 0 && nodeNNIDest >= 0, "Fail to find NNI" );
    MarginalTree mTreeCurr = this->mtree;
    mTreeCurr.PerformSPR(nodeNNI, nodeNNIDest);
    strNNIBestTree = mTreeCurr.GetNewickNoBrLen();
    
    // add on the overall prob of zero for all genotypes
    double prob0All = this->genosInput.CalcSumLogProbAllele0All();
//cout << "ProbZeroAll: " << prob0All << endl;
    double logProbMaxNNIRes = logProbMaxNNI + prob0All;
//cout << "logProbMaxNNIRes: " << logProbMaxNNIRes << ", nodeNNI:" << nodeNNI << ", nodeNNIDest:" << nodeNNIDest << endl;
    
    return logProbMaxNNIRes;
}

int ScistFastNNILocalSearch :: GetNumSites() const
{
    return genosInput.GetNumSites();
}
int ScistFastNNILocalSearch :: GetNumCells() const
{
    return genosInput.GetNumHaps();
}
int ScistFastNNILocalSearch :: GetNumNodesInTree() const
{
    return 2*GetNumCells()-1;
}




// **************************************************************
// Fast re-rooting local search

ScistFastRerootLocalSearch :: ScistFastRerootLocalSearch(const ScistGenGenotypeMat &genosInputIn, const string &strTreeInitIn, int nt) : genosInput(genosInputIn),
    strTreeInit(strTreeInitIn), numThreads(nt)
{
    Init();
}

double ScistFastRerootLocalSearch :: CalcCurrMaxProb() const
{
    double probMaxAll = 0.0;
    for(int site=0; site<GetNumSites(); ++site)
    {
        double val = this->tblM0[site][this->mtree.GetRoot()];
        if( val < 0.0 )
        {
            // if no best cut, then we just choose to not to cut
            val = 0.0;
        }
        probMaxAll += val;
    }
    return probMaxAll;
}

void ScistFastRerootLocalSearch :: GetCurrTree(MarginalTree &treeOut) const
{
    treeOut = mtree;
}


double ScistFastRerootLocalSearch :: GetOptSubtreeReroot( int &nodeSTRootNew, int &nodeST )
{
    if( this->numThreads > 1 && GetNumNodesInTree() > this->numThreads  )
    {
        //
        return GetOptSubtreeRerootMT(nodeSTRootNew, nodeST);
    }
//cout << "GetOptSubtreeReroot: sum of prob 0: " << this->sumLogprobAllele0 << endl;
//cout << "tree: ";
//mtree.Dump();

    // nodeST: the subtree; nodeSTRootNew: a descedant node of nodeST which is the new root
    // best way of rotating the subtree at nodeST so that the resulting Q is max
    vector<pair<int,int> > listRerootCands = this->listCandsReroot;
    /*
    for(unsigned int i=0; i<mapListAnces.size(); ++i)
    {
        int nodeSub = i;
        for(set<int> :: iterator it = mapListAnces[i].begin(); it != mapListAnces[i].end(); ++it)
        {
            int node = *it;
            // skip if nodeSub is direct desendant of node
            if( node == nodeSub || mtree.GetParent(nodeSub) == node )
            {
                continue;
            }
            pair<int,int> pp(nodeSub, node);
            listRerootCands.push_back(pp);
        }
    } */
    vector<double> listProbs( listRerootCands.size() );
    for(unsigned int i=0; i< listRerootCands.size(); ++i)
    {
        //
        int nodeSub = listRerootCands[i].first, node = listRerootCands[i].second;
        
        //
        double probMaxStep = this->sumLogprobAllele0;
        for(int site=0; site<GetNumSites(); ++site)
        {
            double probs = CalcMaxQForReroot(site, node, nodeSub);
//cout << "Max Q value for reroot: site:" << site << ", node:" << node << ", nodeSub:" << nodeSub << " is " << probs << endl;
            probMaxStep += probs;
        }
//cout << "noder: " << noder << ", nodeu: " << nodeu << ", nodew: " << nodew << ", probMaxStep: " << probMaxStep << endl;
        listProbs[i] = probMaxStep;
//cout << "Reroot: node:" << node << ", nodeSub:" << nodeSub << " --- max Q value over ALL sites: " << probMaxStep << endl;
    }
    
    // consider all rSPR move
    double probMax = MAX_NEG_DOUBLE_VAL;
    nodeSTRootNew = -1;
    nodeST = -1;
    // find the best move
    for(unsigned int i=0; i<listRerootCands.size(); ++i)
    {
        double probMaxStep = listProbs[i];
        int nodeu = listRerootCands[i].first;
        int noder = listRerootCands[i].second;
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeSTRootNew = nodeu;
            nodeST = noder;
        }
    }
    
    // if fail to find SPR, just return the smallest
    if( nodeSTRootNew < 0 || nodeST < 0 )
    {
        cout << "Warning: fail to find re-rootiing move. \n";
        return MAX_NEG_DOUBLE_VAL;
    }
    
//cout << "^^^^^^ Max prob of one rerooting move: " << probMax << ", subtree rooted at:" << nodeST << ", to a new node (within the subtree):" << nodeSTRootNew << endl;
    //
    return probMax;
}
    
static void UtilFastRerootSearch2( ScistFastRerootLocalSearch *pthis, int tindex, const std::vector<std::pair<int, int> > *plistRerootCand, unsigned int posStart, unsigned int posEnd, vector<double> *pListProb, vector<int> *pListNodes, vector<int> *pListNodeSTs, double sumLogprobAllele0 )
{
    double probMax = MAX_NEG_DOUBLE_VAL;
    int nodeBest = -1;
    int nodeSTBest = -1;
    
    for(unsigned int i=posStart; i<= posEnd; ++i)
    {
        //
        double probMaxStep = sumLogprobAllele0;
        int nodeSubStep = (*plistRerootCand)[i].first, nodeStep = (*plistRerootCand)[i].second;
        for(int site=0; site<pthis->GetNumSites(); ++site)
        {
            double probs = pthis->CalcMaxQForReroot(site, nodeStep, nodeSubStep);
//cout << "Max Q value for SPR: site:" << site << ", noder:" << noder << ", nodeu:" << nodeu << ", nodew:" << nodew << " is " << probs << endl;
            probMaxStep += probs;
        }
//cout << "--- max Q value over ALL sites: " << probMaxStep << endl;
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeBest = nodeStep;
            nodeSTBest = nodeSubStep;
        }
    }
    // save results
    (*pListProb)[tindex] = probMax;
    (*pListNodes)[tindex] = nodeBest;
    (*pListNodeSTs)[tindex] = nodeSTBest;
}

double ScistFastRerootLocalSearch :: GetOptSubtreeRerootMT( int &nodeSTRootNew, int &nodeST )
{
    // do multi-threading
//cout << "Start multi-threading...\n";
    
    
    // nodeST: the subtree; nodeSTRootNew: a descedant node of nodeST which is the new root
    // best way of rotating the subtree at nodeST so that the resulting Q is max
    vector<pair<int,int> > listRerootCands = this->listCandsReroot;
    /*for(unsigned int i=0; i<mapListAnces.size(); ++i)
    {
        int nodeSub = i;
        for(set<int> :: iterator it = mapListAnces[i].begin(); it != mapListAnces[i].end(); ++it)
        {
            int node = *it;
            // skip if nodeSub is direct desendant of node
            if( node == nodeSub || mtree.GetParent(nodeSub) == node )
            {
                continue;
            }
            pair<int,int> pp(nodeSub, node);
            listRerootCands.push_back(pp);
        }
    } */
    int numThreadsUse = numThreads;
    if( (int)listRerootCands.size() < numThreadsUse )
    {
        numThreadsUse = (int)listRerootCands.size();
    }
    
//cout << "Number of re-rooting candidates: " << listRerootCands.size() << endl;
    
    vector<double> listProbs(numThreadsUse);
    vector<int> listNodes(numThreadsUse);
    vector<int> listNodeSTs(numThreadsUse);
    int numItems = listRerootCands.size();
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilFastRerootSearch2, this, t, &listRerootCands, blkStart, blkEnd, &listProbs, &listNodes, &listNodeSTs, this->sumLogprobAllele0 );
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
    
    // consider all rSPR move
    double probMax = MAX_NEG_DOUBLE_VAL;
    nodeSTRootNew = -1;
    nodeST = -1;
    // find the best move
    for(unsigned int i=0; i<listProbs.size(); ++i)
    {
        double probMaxStep = listProbs[i];
        int node = listNodes[i];
        int nodes = listNodeSTs[i];
        if( probMaxStep > probMax )
        {
            probMax = probMaxStep;
            nodeSTRootNew = nodes;
            nodeST = node;
        }
    }
    
    // if fail to find SPR, just return the smallest
    if( nodeSTRootNew < 0 || nodeST < 0 )
    {
        cout << "Warning: fail to find re-rootiing move. \n";
        return MAX_NEG_DOUBLE_VAL;
    }
    
//cout << "^^^^^^ Max prob of one rerooting move: " << probMax << ", subtree rooted at:" << nodeST << ", to a new node (within the subtree):" << nodeSTRootNew << endl;
    //
    return probMax;
}


// initialization code
void ScistFastRerootLocalSearch :: Init()
{
//cout << "ScistFastSPRLocalSearch :: Init()\n";
    // construct marg tree to work with
    //set<ScistPerfPhyCluster> setClusAllGuide;
    //this->treeGuide.GetAllClusters( setClusAllGuide );
//cout << "Number of clusters: " << setClusAllGuide.size() << endl;
    //string strTree = ConsTreeFromSetClusters( setClusAllGuide );
    //string strTree = this->treeGuide.GetInitTree();
    string strTree = this->strTreeInit;
//cout << "Initial tree: " << strTree << endl;
    ReadinMarginalTreesNewickWLenString(strTree, GetNumCells(), mtree);
    //cout << "Marginal tree: ";
    //mtree.Dump();
    
    SetInitTree(mtree);
}

void ScistFastRerootLocalSearch :: SetInitTree(const MarginalTree &mtreeInit)
{
    this->mtree = mtreeInit;
    // initialize ancestral relations
    mapListAnces.clear();
    mapListAnces.resize( mtree.GetTotNodesNum() );
    for(int node=0; node<mtree.GetTotNodesNum(); ++node)
    {
        int nodeAnces = node;
        set<int> ss;
        while(true)
        {
            ss.insert(nodeAnces);
            if( mtree.GetRoot() == nodeAnces)
            {
                break;
            }
            else
            {
                nodeAnces = mtree.GetParent(nodeAnces);
            }
        }
        mapListAnces[node] = ss;
    }
//cout << "Now initialize tables\n";
    InitQTbl();
    InitM0Tbl();
    InitM1Tbl();
    InitM2Tbl();
    // Init tblM4 first
    InitM4Tbl();
    
    // collect candidates
    CollectRerootCands();
    
    // init prob
    this->sumLogprobAllele0 = this->genosInput.CalcSumLogProbAllele0All();
    this->logProbCurr = CalcCurrMaxProb();
    this->logProbCurr += this->sumLogprobAllele0;
}
void ScistFastRerootLocalSearch :: InitQTbl()
{
    this->tblQ.clear();
    this->tblQ.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblQ[s].resize( mtree.GetTotNodesNum() );
    }
    //
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "InitQTbl: site:" << site << endl;
        // do a bottom up
        vector<double> listNodeSplitProb;
        // init to be bad
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            listNodeSplitProb.push_back( -1.0*HAP_MAX_INT );
        }
        
    //cout << "CalcProbMaxForSiteHap: mtree: " << mtree.GetNewickSorted(false) << endl;
    //mtree.Dump();
        
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            //cout << "node " << node << endl;
            double logpStep = 0.0;
            if( mtree.IsLeaf(node) )
            {
                // a single leaf in the split
                int lvlbl = mtree.GetLabel(node)-1;
                //cout << "Leaf: " << lvlbl << endl;
                double p0 = this->genosInput.GetGenotypeProbAllele0At(lvlbl, site);
                if( p0 < YW_VERY_SMALL_FRACTION)
                {
                    p0 = YW_VERY_SMALL_FRACTION;
                }
                else if( p0 > 1.0-YW_VERY_SMALL_FRACTION)
                {
                    p0 = 1.0-YW_VERY_SMALL_FRACTION;
                }
                logpStep = log((1-p0)/p0);
    //cout << "Set leaf " << node << " log prob to: " << logpStep << ", p0=" << p0 << endl;
            }
            else
            {
                // get the two children and add them up
                int childLeft = mtree.GetLeftDescendant(node);
                int childRight = mtree.GetRightDescendant(node);
    //cout << "node: " << node << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
                //cout << "childLeft: " << childLeft << ", right: " << childRight << endl;
                
                YW_ASSERT_INFO( listNodeSplitProb[childLeft] > -1.0*HAP_MAX_INT, "Bad left-a" );
                YW_ASSERT_INFO( listNodeSplitProb[childRight] > -1.0*HAP_MAX_INT, "Bad right1-a" );
                logpStep = listNodeSplitProb[childLeft] + listNodeSplitProb[childRight];
            }
//cout << "log prob: " << logpStep << " for node: " << node << endl;
            listNodeSplitProb[node] = logpStep;
        }
        
        // save the probs
        this->tblQ[site] = listNodeSplitProb;
    }
}

void ScistFastRerootLocalSearch :: InitM0Tbl()
{
//cout << "InitM0Tbl: " << endl;
    // collect the maximum Q values of each subtree
    this->tblM0.clear();
    this->tblM0.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM0[s].resize( mtree.GetTotNodesNum() );
    }
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            if( mtree.IsLeaf(node) )
            {
                // a single leaf in the split
                tblM0[site][node] = tblQ[site][node];
            }
            else
            {
                // get the two children and add them up
                int childLeft = mtree.GetLeftDescendant(node);
                int childRight = mtree.GetRightDescendant(node);
    //cout << "node: " << node << ", childLeft: " << childLeft << ", childRight: " << childRight << endl;
                //cout << "childLeft: " << childLeft << ", right: " << childRight << endl;
                
                YW_ASSERT_INFO( tblM0[site][childLeft] > -1.0*HAP_MAX_INT, "Bad left-b" );
                YW_ASSERT_INFO( tblM0[site][childRight] > -1.0*HAP_MAX_INT, "Bad right1-b" );
                double probM0 = std::max(tblM0[site][childLeft], tblM0[site][childRight]);
                tblM0[site][node] = std::max(probM0, tblQ[site][node]);
            }
//cout << "Set tblM0: site:" << site << ", node:" << node << ", to: " << tblM0[site][node] << endl;
        }
    }
}
void ScistFastRerootLocalSearch :: InitM1Tbl()
{
    //if( this->numThreads > 1 && GetNumSites() > this->numThreads )
    if( this->numThreads > 1 )
    {
        InitM1TblMT();
        return;
    }
    this->tblM1.clear();
    this->tblM1.resize( GetNumSites() );
//cout << "InitM1Tbl: " << endl;
    // first iterate over sites
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        this->tblM1[site].resize(mtree.GetTotNodesNum());
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            // trace up until reaching the root
            int nodeAnces = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                this->tblM1[site][node][nodeAnces] = probMaxPath;
//cout << "Set tblM1: site:" << site << ", node:" << node << ", nodeAnces: " << nodeAnces << ", to: " << tblM1[site][node][nodeAnces] << endl;
                double prob2 = this->tblQ[site][nodeAnces];
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
                
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
}

// muliti-threading
static void UtilsInitM1Tbl2( ScistFastRerootLocalSearch *pthis, MarginalTree *ptree, int posStart, int posEnd, std::vector<std::vector< std::map<int,double> > > *pTblM1 )
{
    // first iterate over sites
    for(int site=posStart; site<=posEnd; ++site)
    {
        // do iteration over each node from bottom up
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            // trace up until reaching the root
            int nodeAnces = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                (*pTblM1)[site][node][nodeAnces] = probMaxPath;
//cout << "Set tblM1: site:" << site << ", node:" << node << ", nodeAnces: " << nodeAnces << ", to: " << tblM1[site][node][nodeAnces] << endl;
                double prob2 = pthis->GetQVal(site, nodeAnces);
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
                if( nodeAnces == ptree->GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAnces = ptree->GetParent(nodeAnces);
                }
            }
        }
    }
}
void ScistFastRerootLocalSearch :: InitM1TblMT()
{
//cout << "InitM1TblMT:\n";
    this->tblM1.clear();
    this->tblM1.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM1[s].resize(  GetNumNodesInTree() );
    }

    int numItems = GetNumSites();
    int blkSize = numItems/this->numThreads;
    int blkStart = 0;
    int numThreadsUse = this->numThreads;
    if( this->numThreads > GetNumSites() )
    {
        numThreadsUse = GetNumSites();
    }
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitM1Tbl2, this, &mtree, blkStart, blkEnd, &tblM1);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "InitM1TblMT: multithreading done\n";
}

void ScistFastRerootLocalSearch :: InitM2Tbl()
{
    if( this->numThreads > 1 )
    {
        InitM2TblMT();
        return;
    }
//cout << "^^^^^^^Init M2:\n";
    this->tblM2.clear();
    this->tblM2.resize( GetNumSites() );

    // first iterate over sites
    for(int site=0; site<GetNumSites(); ++site)
    {
        this->tblM2[site].resize(mtree.GetTotNodesNum());
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            if( node == mtree.GetRoot() )
            {
                continue;
            }
            
            // trace up until reaching the root
            int nodeAnces = mtree.GetParent( node );
            int nodeAncesBelow = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                this->tblM2[site][node][nodeAnces] = probMaxPath;
//cout << "set M2: node:" << node << ", nodeAnces: " << nodeAnces << " to : " << probMaxPath << endl;
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAncesBelow = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
                // get the side chain at nodeAnces
                int nodeSide = mtree.GetLeftDescendant(nodeAncesBelow);
                if( IsNodeAncestralTo( nodeSide, node) )
                {
                    nodeSide = mtree.GetRightDescendant(nodeAncesBelow);
                }
                //YW_ASSERT_INFO(nodeSide != nodeAncesBelow, "Fail to find side chain node");
//cout << "nodeside:" << nodeSide << ", node: " << node << ", M0: at side node: " << this->tblM0[site][nodeSide] << endl;
                
                double prob2 = this->tblM0[site][nodeSide];
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
            }
        }
    }
}

// multi-threading
static void UtilsInitM2Tbl2(ScistFastRerootLocalSearch *pthis, MarginalTree *ptree, int posStart, int posEnd, std::vector<std::vector< std::map<int,double> > > *pTblM2)
{
    // first iterate over sites
    for(int site=posStart; site<=posEnd; ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            if( node == ptree->GetRoot() )
            {
                continue;
            }
            
            // trace up until reaching the root
            int nodeAnces = ptree->GetParent( node );
            int nodeAncesBelow = node;
            double probMaxPath = MAX_NEG_DOUBLE_VAL;
            while(nodeAnces >= 0)
            {
                //
                (*pTblM2)[site][node][nodeAnces] = probMaxPath;
//cout << "set M2: node:" << node << ", nodeAnces: " << nodeAnces << " to : " << probMaxPath << endl;
                if( nodeAnces == ptree->GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeAncesBelow = nodeAnces;
                    nodeAnces = ptree->GetParent(nodeAnces);
                }
                // get the side chain at nodeAnces
                int nodeSide = ptree->GetLeftDescendant(nodeAncesBelow);
                if( pthis->IsNodeAncestralTo( nodeSide, node) )
                {
                    nodeSide = ptree->GetRightDescendant(nodeAncesBelow);
                }
                //YW_ASSERT_INFO(nodeSide != nodeAncesBelow, "Fail to find side chain node");
//cout << "nodeside:" << nodeSide << ", node: " << node << ", M0: at side node: " << this->tblM0[site][nodeSide] << endl;
                
                double prob2 = pthis->GetM0Val(site, nodeSide);
                if( prob2 > probMaxPath )
                {
                    probMaxPath = prob2;
                }
            }
        }
    }
}

void ScistFastRerootLocalSearch :: InitM2TblMT()
{
//cout << "^^^^^^^Init M2:\n";
    this->tblM2.clear();
    this->tblM2.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM2[s].resize( GetNumNodesInTree() );
    }

    int numItems = GetNumSites();
    int numThreadsUse = this->numThreads;
    if( numThreadsUse > numItems )
    {
        numThreadsUse = numItems;
    }
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitM2Tbl2, this, &mtree, blkStart, blkEnd, &tblM2);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "InitM2TblMT: multithreading done\n";
}

void ScistFastRerootLocalSearch :: InitM4Tbl()
{
    tblM4.clear();
    this->tblM4.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM4[s].resize( GetNumNodesInTree() );
    }
    /*tblM5.clear();
    this->tblM5.resize( GetNumSites() );
    for(int s=0; s<GetNumSites(); ++s)
    {
        this->tblM5[s].resize( GetNumNodesInTree() );
    }*/
    
    if( this->numThreads > 1 )
    {
        InitM4TblMT();
        return;
    }
    
    // collect M4[s][nodeu][noder] = max partial sum of off-path [noder->nodeu] Q values
    // now collect M4
    for(int site=0; site<GetNumSites(); ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<mtree.GetTotNodesNum(); ++node)
        {
            tblM4[site][node][node] = 0;
            // trace up until reaching the root
            int nodeCurr = node;
            int nodeAnces = mtree.GetParent(node);
            tblM4[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = mtree.GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    int nodeSib = mtree.GetSibling(nodeCurr);
                    tblM4[site][node][nodeAncesAnces] = std::max( tblM4[site][node][nodeAnces] + this->tblQ[site][nodeSib], this->tblQ[site][nodeSib]);
//cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == mtree.GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeCurr = nodeAnces;
                    nodeAnces = mtree.GetParent(nodeAnces);
                }
            }
        }
    }
    //cout << "Done with tblM4 init.\n";
}

// multi-threading
static void UtilsInitM4Tbl2(ScistFastRerootLocalSearch *pthis, MarginalTree *ptree, int posStart, int posEnd, std::vector<std::vector< std::map<int,double> > > *pTblM4)
{
    // first iterate over sites
    for(int site=posStart; site<=posEnd; ++site)
    {
//cout << "site: " << site << endl;
        // do iteration over each node from bottom up
        for(int node=0; node<ptree->GetTotNodesNum(); ++node)
        {
            (*pTblM4)[site][node][node] = 0;
            // trace up until reaching the root
            int nodeCurr = node;
            int nodeAnces = ptree->GetParent(node);
            (*pTblM4)[site][node][nodeAnces] = 0;
            while(nodeAnces >= 0)
            {
                //
                int nodeAncesAnces = ptree->GetParent(nodeAnces);
                if( nodeAncesAnces >= 0 )
                {
                    int nodeSib = ptree->GetSibling(nodeCurr);
                    double prob2 = pthis->GetQVal(site, nodeSib);
                    (*pTblM4)[site][node][nodeAncesAnces] = std::max( (*pTblM4)[site][node][nodeAnces] + prob2, prob2 );
                    //cout << "Set tblM4: site:" << site << ", node:" << node << ", nodeAncesAnces: " << nodeAncesAnces << ", to: " << tblM4[site][node][nodeAncesAnces] << "      tblQ[sib] = " << this->tblQ[site][nodeSib] << endl;
                }
                if( nodeAnces == ptree->GetRoot() )
                {
                    break;
                }
                else
                {
                    nodeCurr = nodeAnces;
                    nodeAnces = ptree->GetParent(nodeAnces);
                }
            }
        }
    }
}


void ScistFastRerootLocalSearch :: InitM4TblMT()
{
    int numItems = GetNumSites();
    int numThreadsUse = this->numThreads;
    if( numThreadsUse > numItems )
    {
        numThreadsUse = numItems;
    }
    int blkSize = numItems/numThreadsUse;
    int blkStart = 0;
//cout << "InitM4TblMT : numThresuse: " << numThreadsUse << ", blk size: " << blkSize << endl;
    vector<thread *> listPtrThreads;
    for(int t=0; t<numThreadsUse; ++t)
    {
        int blkEnd = blkStart + blkSize - 1;
        if( blkEnd >= numItems  || t == numThreadsUse-1)
        {
            blkEnd = numItems-1;
        }
        YW_ASSERT_INFO(blkEnd >= blkStart, "WRONG345");
        // start thread
        thread *pthr = new thread(UtilsInitM4Tbl2, this, &mtree, blkStart, blkEnd, &tblM4);
        listPtrThreads.push_back(pthr);
        blkStart += blkSize;
    }
    
    // wait to join
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      listPtrThreads[j]->join();
    }
    for(unsigned int j=0; j<listPtrThreads.size(); ++j)
    {
      delete listPtrThreads[j];
    }
    listPtrThreads.clear();
//cout << "Done with InitM4TblMT\n";
}

//*************************************************************
bool ScistFastRerootLocalSearch :: IsNodeAncestralTo(int node1, int node2) const
{
    // is node1 ancestral to node2?
    //map<int, set<int> > :: const_iterator it1 = mapListAnces.find(node2);
    //return it1->second.find(node1) != it1->second.end();
    return mapListAnces[node2].find(node1) != mapListAnces[node2].end();
}

int ScistFastRerootLocalSearch :: GetNumSites() const
{
    return genosInput.GetNumSites();
}
int ScistFastRerootLocalSearch :: GetNumCells() const
{
    return genosInput.GetNumHaps();
}
int ScistFastRerootLocalSearch :: GetNumNodesInTree() const
{
    return 2*GetNumCells()-1;
}
std::string ScistFastRerootLocalSearch :: ConsTreeFromSetClusters( const std::set<ScistPerfPhyCluster> &setClusters ) const
{
    //
    // now construct tree
    ScistInfPerfPhyUtils treeBuild;
    map<int, ScistPerfPhyCluster> mapPickedClus;
    int s = 0;
    for(set<ScistPerfPhyCluster>:: iterator it = setClusters.begin(); it != setClusters.end(); ++it)
    {
        mapPickedClus[s] = *it;
        ++s;
    }
    string strTree = treeBuild.ConsTreeWCombDistClus( this->genosInput, mapPickedClus );
    return strTree;
}

double ScistFastRerootLocalSearch :: CalcMaxQForReroot(int site, int node, int nodeSub) const
{
//cout << "CalcMaxQForReroot: site:" << site << ", node:" << node << ", nodeSub:" << nodeSub << endl;

    // get the child of node that is not ancestral nodeSub (i.e., on the other side)
    int nodeChildOther = mtree.GetLeftDescendant(node);
    if( IsNodeAncestralTo(nodeChildOther, nodeSub) )
    {
        nodeChildOther = mtree.GetRightDescendant(node);
    }
    
    // prob1: max within subtree nodeSub
    double prob1 = this->tblM0[site][nodeSub];
    // prob2: max within subtree nodeOtherChild
    double prob2 = this->tblM0[site][nodeChildOther];
    // prob3: the original Q at node
    double prob3 = this->tblQ[site][node];
    
    map<int, double> :: const_iterator it2;
    // prob4: max of Q among side chains off the path node to nodeSub
    //it2 = this->tblM2[site][nodeSub].find(node);
    //YW_ASSERT_INFO(it2 != this->tblM2[site][nodeSub].end(), "Fail112-1");
    //double prob4 = it2->second;
    // prob5: max along path from node to root
    double prob5 = MAX_NEG_DOUBLE_VAL;
    if( node != mtree.GetRoot() )
    {
        it2 = this->tblM1[site][node].find(mtree.GetRoot());
        YW_ASSERT_INFO(it2 != this->tblM1[site][node].end(), "Fail112-5");
        prob5 = it2->second;;
    }
    // prob6: max along nodes from
    double prob6 = MAX_NEG_DOUBLE_VAL;
    it2 = this->tblM2[site][nodeSub].find(mtree.GetRoot());
    YW_ASSERT_INFO(it2 != this->tblM2[site][nodeSub].end(), "Fail112-5");
    prob6 = it2->second;
    //}
    // prob7: max over the other side of subtree
    double prob7 = MAX_NEG_DOUBLE_VAL;
    if( node != mtree.GetRoot() )
    {
        int childRootOtherSide = mtree.GetLeftDescendant(mtree.GetRoot());
        if( this->mapListAnces[node].find(childRootOtherSide) != this->mapListAnces[node].end() )
        {
            childRootOtherSide = mtree.GetRightDescendant(mtree.GetRoot());
        }
        prob7 = this->tblM0[site][childRootOtherSide];
    }
    double prob8 = MAX_NEG_DOUBLE_VAL;
    int nodev1 = mtree.GetParent(nodeSub);
    if( nodev1 != node )
    {
        it2 = this->tblM4[site][nodeSub].find(node);
        YW_ASSERT_INFO(it2 != this->tblM4[site][nodeSub].end(), "Fail112-6");
        prob8 = it2->second + this->tblQ[site][nodeChildOther];
    }
    
    // finally allow the root Q value to be included
    double prob9 = this->tblQ[site][mtree.GetRoot()];
//cout << "CalcMaxQReroot: p1:" << prob1 << ", p2:" << prob2 << ", p3:" << prob3 << ", p5:" << prob5 << ", p6:" << prob6 << ", p7:" << prob7 << ", p8:" << prob8 << ", p9:" << prob9 << endl;
    double res = std::max(prob1, std::max(prob2, std::max(prob3, std::max(prob5, std::max(prob6, std::max(prob7, std::max(prob8, prob9 )))))));
    if( res < 0.0 )
    {
        res = 0.0;
    }
    return res;
}

void ScistFastRerootLocalSearch :: CollectRerootCands( )
{
    //
    listCandsReroot.clear();
    for(unsigned int i=0; i<mapListAnces.size(); ++i)
    {
        int nodeSub = i;
        for(set<int> :: iterator it = mapListAnces[i].begin(); it != mapListAnces[i].end(); ++it)
        {
            int node = *it;
            // skip if nodeSub is direct desendant of node
            if( node == nodeSub || mtree.GetParent(nodeSub) == node )
            {
                continue;
            }
            pair<int,int> pp(nodeSub, node);
            listCandsReroot.push_back(pp);
        }
    }
}
